#ifndef PC1681WE05_h
#define PC1681WE05_h

#include <Arduino.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>

class PC1681WE05 {
public:
    PC1681WE05();
    void initLCD();
    void lcdOn();
    void lcdOff();
    void setBacklight(unsigned char light);
    void writeBitmap();
    void writeBlank();
    void writeChar(int x, int y, char ch, bool invert);
    void LCDWriteString(int row, int pos, unsigned char* arr, int inv);
    void refresh();
private:
    void *memcpy_Pinv(void *dest, PGM_VOID_P src, size_t nbytes);
};

#endif
