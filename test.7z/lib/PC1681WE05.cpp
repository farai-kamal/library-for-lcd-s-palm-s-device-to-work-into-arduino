#include "PC1681WE05.h"
#include "font_8x8.h"
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>

extern unsigned char bitmap[160 * 20];

#define lcd_delay 100  //30534 - old

#define CP_PIN 0
#define DISP_PIN 1
#define VHH_PIN 2
#define LP_PIN 3
#define FLM_PIN 4
#define D3_PIN 5
#define D2_PIN 6
#define D1_PIN 7
#define D0_PIN 8
#define EL2_PIN 9
#define EL1_PIN 10
#define EN_PIN 11

#define EN_OFF digitalWrite(EN_PIN, LOW)
#define EN_ON digitalWrite(EN_PIN, HIGH)
#define DISP_OFF digitalWrite(DISP_PIN, LOW)
#define DISP_ON digitalWrite(DISP_PIN, HIGH)
#define VHH_OFF digitalWrite(VHH_PIN, LOW)
#define VHH_ON digitalWrite(VHH_PIN, HIGH)
#define LP_LOW digitalWrite(LP_PIN, LOW)
#define LP_HIGH digitalWrite(LP_PIN, HIGH)
#define FLM_LOW digitalWrite(FLM_PIN, LOW)
#define FLM_HIGH digitalWrite(FLM_PIN, HIGH)
#define D3_LOW digitalWrite(D3_PIN, LOW)
#define D3_HIGH digitalWrite(D3_PIN, HIGH)
#define D2_LOW digitalWrite(D2_PIN, LOW)
#define D2_HIGH digitalWrite(D2_PIN, HIGH)
#define D1_LOW digitalWrite(D1_PIN, LOW)
#define D1_HIGH digitalWrite(D1_PIN, HIGH)
#define D0_LOW digitalWrite(D0_PIN, LOW)
#define D0_HIGH digitalWrite(D0_PIN, HIGH)
#define EL2_LOW digitalWrite(EL2_PIN, LOW)
#define EL2_HIGH digitalWrite(EL2_PIN, HIGH)
#define EL1_LOW digitalWrite(EL1_PIN, LOW)
#define EL1_HIGH digitalWrite(EL1_PIN, HIGH)
#define EN_LOW digitalWrite(EN_PIN, LOW)
#define EN_HIGH digitalWrite(EN_PIN, HIGH)

PC1681WE05::PC1681WE05() {
  pinMode(CP_PIN, OUTPUT);
  pinMode(DISP_PIN, OUTPUT);
  pinMode(VHH_PIN, OUTPUT);
  pinMode(LP_PIN, OUTPUT);
  pinMode(FLM_PIN, OUTPUT);
  pinMode(D3_PIN, OUTPUT);
  pinMode(D2_PIN, OUTPUT);
  pinMode(D1_PIN, OUTPUT);
  pinMode(D0_PIN, OUTPUT);
  pinMode(EL2_PIN, OUTPUT);
  pinMode(EL1_PIN, OUTPUT);
  pinMode(EN_PIN, OUTPUT);
}

void PC1681WE05::initLCD() {
  // Initialize LCD controler
  DISP_OFF;
  VHH_OFF;
  LP_LOW;
  FLM_LOW;
  D3_LOW;
  D2_LOW;
  D1_LOW;
  D0_LOW;
  EL2_LOW;
  EL1_LOW;
}

void PC1681WE05::lcdOn() {
  volatile unsigned int i = 0;

  // delay
   for(i=0; i<65534; i++);
  	EN_ON;

  // delay	30534 - old
  for (i = 0; i < lcd_delay; i++)
    ;
  VHH_ON;

  // delay
  for (i = 0; i < lcd_delay; i++)
    ;
  DISP_ON;

  // delay
  for (i = 0; i < lcd_delay; i++)
    ;
}

void PC1681WE05::lcdOff() {
  volatile unsigned int i = 0;

  // delay
  for (i = 0; i < lcd_delay; i++)
    ;

  DISP_OFF;

  // delay
  for (i = 0; i < lcd_delay; i++)
    ;

  VHH_OFF;

  // delay
  for (i = 0; i < lcd_delay; i++)
    ;

  EN_OFF;
  // delay
  for (i = 0; i < 65534; i++)
    ;
}

void PC1681WE05::setBacklight(unsigned char light) {
  switch (light) {
    case 0:
      EL1_LOW;
      EL2_LOW;
      break;
    case 1:
      EL1_LOW;
      EL2_HIGH;
      break;
    case 2:
      EL2_LOW;
      EL1_HIGH;
      break;
    default:
      EL1_LOW;
      EL2_LOW;
      break;
  }
}

void PC1681WE05::writeBitmap() {

  // variable for loop cycle
  unsigned int i = 0;
  unsigned int j = 0;

  // loop for every row
  // for(i=20; i<(160*20); i+=20) {
  for (i = 0; i < (3200); i += 20) {
    // loop for every col
    for (j = 0; j < 20; j++) {

      // get data
      unsigned char pl = bitmap[i + j];
      unsigned char ph = pl >> 4;
      pl &= 0xF;

      //IO0CLR = 0x001E0000;
      //IO0SET = LookUpSet[ph];

      // clock CP
      //IO0CLR = BIT21; - do it with OC1C

      //IO0CLR = 0x001E0000;
      //IO0SET = LookUpSet[pl];

      // clock CP
      //IO0CLR = BIT21; - do it with OC1C
    }

    if (i) {
      LP_HIGH;
      LP_LOW;
    } else {
      // start new frame
      // for every new frame
      FLM_HIGH;
      LP_HIGH;
      LP_LOW;
      FLM_LOW;
    }
  }

  LP_HIGH;
  LP_LOW;
}

//Blank screen***************************************************

void PC1681WE05::writeBlank() {
  for (int i = 0; i < (3200); i += 20) {
    // loop for every col
    for (int j = 0; j < 20; j++) {
      bitmap[i + j] = 0;
    }
  }
}
// Write char to LCD at specify position
// x, y is coordinate
// invert is 0 or 1 - invert text
void PC1681WE05::writeChar(int x, int y, char ch, bool invert) {
#if 0
		 PGM_P p;
		switch(nmb){
			case 0:	memcpy_P(myrow[pos], &FontLookup[ch-32][0], 8);
	    		break;
			case 1:	memcpy_P(myrow2[pos], &FontLookup[ch-32][0], 8);
	    		break;
			case 2:	memcpy_P(myrow3[pos], &FontLookup[ch-32][0], 8);
	    		break;
			case 3:	memcpy_P(myrow4[pos], &FontLookup[ch-32][0], 8);
	    		break;
			case 4:	memcpy_P(myrow5[pos], &FontLookup[ch-32][0], 8);
	    		break;
			case 5:	memcpy_P(myrow6[pos], &FontLookup[ch-32][0], 8);
	    		break;
			case 6:	memcpy_P(myrow7[pos], &FontLookup[ch-32][0], 8);
    			break;
			case 7:	memcpy_P(myrow8[pos], &FontLookup[ch-32][0], 8);
    			break;
			case 8:	memcpy_P(myrow9[pos], &FontLookup[ch-32][0], 8);
    			break;
			case 9:	memcpy_P(myrow10[pos], &FontLookup[ch-32][0], 8);
    			break;
			case 5:	memcpy_P(myrow6[pos], &FontLookup[ch-32][0], 8);
    			break;
		}
    // END of switch
#endif

#if 1
  if (!invert) {
    memcpy_P(&bitmap[(x + 1) * 20 + y], &FontLookup[ch - 32][0], 1);  //bitmap[(x+1)*20+y] = FontLookup[ch-32][0];
    memcpy_P(&bitmap[(x + 2) * 20 + y], &FontLookup[ch - 32][1], 1);  //bitmap[(x+2)*20+y] = FontLookup[ch-32][1];
    memcpy_P(&bitmap[(x + 3) * 20 + y], &FontLookup[ch - 32][2], 1);  //bitmap[(x+3)*20+y] = FontLookup[ch-32][2];
    memcpy_P(&bitmap[(x + 4) * 20 + y], &FontLookup[ch - 32][3], 1);  //bitmap[(x+4)*20+y] = FontLookup[ch-32][3];
    memcpy_P(&bitmap[(x + 5) * 20 + y], &FontLookup[ch - 32][4], 1);  //bitmap[(x+5)*20+y] = FontLookup[ch-32][4];
    memcpy_P(&bitmap[(x + 6) * 20 + y], &FontLookup[ch - 32][5], 1);  //bitmap[(x+6)*20+y] = FontLookup[ch-32][5];
    memcpy_P(&bitmap[(x + 7) * 20 + y], &FontLookup[ch - 32][6], 1);  //bitmap[(x+7)*20+y] = FontLookup[ch-32][6];
    memcpy_P(&bitmap[(x + 8) * 20 + y], &FontLookup[ch - 32][7], 1);  //bitmap[(x+8)*20+y] = FontLookup[ch-32][7];
  } else {
    memcpy_Pinv(&bitmap[(x + 1) * 20 + y], &FontLookup[ch - 32][0], 1);  //bitmap[(x+1)*20+y] = ~FontLookup[ch-32][0];
    memcpy_Pinv(&bitmap[(x + 2) * 20 + y], &FontLookup[ch - 32][1], 1);  //bitmap[(x+2)*20+y] = ~FontLookup[ch-32][1];
    memcpy_Pinv(&bitmap[(x + 3) * 20 + y], &FontLookup[ch - 32][2], 1);  //bitmap[(x+3)*20+y] = ~FontLookup[ch-32][2];
    memcpy_Pinv(&bitmap[(x + 4) * 20 + y], &FontLookup[ch - 32][3], 1);  //bitmap[(x+4)*20+y] = ~FontLookup[ch-32][3];
    memcpy_Pinv(&bitmap[(x + 5) * 20 + y], &FontLookup[ch - 32][4], 1);  //bitmap[(x+5)*20+y] = ~FontLookup[ch-32][4];
    memcpy_Pinv(&bitmap[(x + 6) * 20 + y], &FontLookup[ch - 32][5], 1);  //bitmap[(x+6)*20+y] = ~FontLookup[ch-32][5];
    memcpy_Pinv(&bitmap[(x + 7) * 20 + y], &FontLookup[ch - 32][6], 1);  //bitmap[(x+7)*20+y] = ~FontLookup[ch-32][6];
    memcpy_Pinv(&bitmap[(x + 8) * 20 + y], &FontLookup[ch - 32][7], 1);  //bitmap[(x+8)*20+y] = ~FontLookup[ch-32][7];
  }
#endif
}

void PC1681WE05::LCDWriteString(int row, int pos, unsigned char* arr, int inv) {

  unsigned int i = pos;

  while((*arr) != '\0') {

   // LCDWriteChar(row, i, (*arr), inv);
    writeChar(row, i, (*arr), inv);

    i++;
    arr++;

  }

}

void PC1681WE05::refresh() {
  // Implement refreshing display
}


void *PC1681WE05::memcpy_Pinv(void * start1, PGM_VOID_P start2, size_t nbytes){

	uint8_t *p1 = (uint8_t*)start1;
	uint8_t *p2 = (uint8_t*)start2;
	unsigned char tmp;
	while(nbytes--) {
		memcpy_P(&tmp,start2++,1);//*p1++ = (uint8_t)(~*p2++);
		tmp=~tmp;
		memcpy(start1++,&tmp,1);
	}
}

