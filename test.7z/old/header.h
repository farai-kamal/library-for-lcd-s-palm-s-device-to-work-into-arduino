/*extern*/ register unsigned char data_counter asm("r3");
/*extern*/ register unsigned char line_counter asm("r4");
