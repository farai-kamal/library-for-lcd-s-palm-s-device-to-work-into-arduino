// PC1681WE05.h
//_____ I N C L U D E S ________________________________________________________
//#include "compiler.h"
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>

// ON/OFF LCD
#define EN_ON     PORTC = PORTC | 1<<PC6
#define EN_OFF    PORTC = PORTC & ~(1<<PC6)

// ON/OFF LCD
#define DISP_ON     PORTA = PORTA | 1<<PA6
#define DISP_OFF    PORTA = PORTA & ~(1<<PA6)

// ON/OFF LCD
#define VHH_ON      PORTA = PORTA | 1<<PA7
#define VHH_OFF     PORTA = PORTA & ~(1<<PA7)

// D3
#define D3_HIGH     PORTA = PORTA | 1<<PA3
#define D3_LOW      PORTA = PORTA & ~(1<<PA3)

// D2
#define D2_HIGH     PORTA = PORTA | 1<<PA2
#define D2_LOW      PORTA = PORTA & ~(1<<PA2)

// D1
#define D1_HIGH     PORTA = PORTA | 1<<PA1
#define D1_LOW      PORTA = PORTA & ~(1<<PA1)

// D0
#define D0_HIGH     PORTA = PORTA | 1<<PA0
#define D0_LOW      PORTA = PORTA & ~(1<<PA0)

// CP
#define CP_HIGH		PORTB = PORTB | 1<<PB7
#define CP_LOW      PORTB = PORTB & ~(1<<PB7)

// LP
#define LP_HIGH     PORTA = PORTA | 1<<PA5
#define LP_LOW      PORTA = PORTA & ~(1<<PA5)

// FLM
#define FLM_HIGH    PORTA = PORTA | 1<<PA4
#define FLM_LOW     PORTA = PORTA & ~(1<<PA4)

// EL2
//#define EL2_HIGH    IO0SET_bit.P0_25 = 1
//#define EL2_LOW     IO0CLR_bit.P0_25 = 1

// EL1
//#define EL1_HIGH    IO0SET_bit.P0_23 = 1
//#define EL1_LOW     IO0CLR_bit.P0_23 = 1

// BACKLIGHT
//#define LIGHT_OFF       0
//#define LIGHT_YELLOW    1
//#define LIGHT_GREEN     2

void * memcpy_Pinv(void * start1, PGM_VOID_P start2, size_t nbytes);
// Init LCD Controler
void InitLCD();
// Turn ON LCD
void LCD_On();
// Turn OFF LCD
void LCD_Off();
// Write array to LCD
void LCDWriteArray(unsigned char* arr);
//Write Blank Screen
void LCDWriteBlank(void);
// Write char to LCD at specify position
void LCDWriteChar(int nmb,int pos,int x, int y, char ch, char invert);
// Set backlight
void SetBackLight(unsigned char light);
// Refresh LCD
void Refresh(void);
// Write bitmap
void LCDWriteBitmap(void);
// Write string
void LCDWriteString(int row, int pos, unsigned char* arr, int inv);

// TouchScreen
// get adc value from X coordinate
unsigned int GetX_value(void);
// get adc value Y coordinate
unsigned int GetY_value(void);


