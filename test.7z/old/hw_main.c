//_____ I N C L U D E S ________________________________________________________
#include "lib_mcu/compiler.h"
#include <avr/io.h>
#include <avr/interrupt.h>

#include "header.h"
#include "timer16_drv.h"
#include "timer8_drv.h"

#include "lcd.h"  //user defined
#include "mmc.h"  //user-defined

//#include "i2c_drv.h"
#include "smb380_drv.h"

#define ADC_PRESCALER 0x06
//_____________DEFINITIONS___________________________________________________________
//LCD

char menu[4]={'M','E','N','U'};
char board_name[12]= {'A','V','R','-','T','L','C','D',' ','C','A','N'};
char test_ext[14]  = {'T','e','s','t',' ','e','x','t','e','n','s','i','o','n'};
char test_mmc[8]  = {'T','e','s','t',' ','M','M','C'};
char test_can[8]  = {'T','e','s','t',' ','C','A','N'};
char test_acc[16]  = {'T','e','s','t',' ','a','c','c','e','l','e','r','a','t','o','r'};
char success[7]={'S','U','C','C','E','S','S'};
char error[5]={'E','R','R','O','R'};

//Accelerator

#define START	0x08
#define MT_SLA_ACK	0x18
#define MT_SLA_NACK	0x20
#define MT_DATA_ACK 0x28
#define MT_DATA_NACK 0x30
#define MR_SLA_ACK	0x40
#define MR_DATA_ACK 0x50
#define MR_DATA_NACK 0x58
#define SLA_W	0b10010000
#define SLA_R	0b10010001
#define SLA2_W	0b10010010
#define SLA2_R	0b10010011
#define START	0x08
#define MT_SLA_ACK	0x18
#define MT_SLA_NACK	0x20
#define MT_DATA_ACK 0x28
#define MT_DATA_NACK 0x30
#define MR_SLA_ACK	0x40
#define MR_DATA_ACK 0x50
#define MR_DATA_NACK 0x58

unsigned char old_value=0;
unsigned char reg[2];
unsigned char	read_reg=0;
extern volatile int	  I2CState;
extern LPC_I2C_Msg_t	  I2CMsg;
//unsigned char reg2[2]={0x15,0x01};
//I2C sensor
unsigned char TCN_Conf;
unsigned int TCN_Data;
unsigned char TCN_raddr,TCN_waddr;
int er=0;
U8 xl=0,xh=0,yl=0,yh=0,zl=0,zh=0;
uint16_t temph,templ,temp;
double tempwr;	
double tempwr2;




//_____________DECLARATIONS__________________________________________________________
//LCD characters array
unsigned char bitmap[160*20];
int control=0;
int timeout=0;
unsigned char flag=0;
int line=0;
int frame=0;
//int data_counter=40;
//int line_counter=160;
int togle_pixel=0;

//ADC vairables
//volatile unsigned short myx=0;
volatile unsigned short myy=0;
int choice=0;

//MMC variables
extern char mmc_buffer[128];
char mmc_buffer_test_1[128];
char state_mmc  = 1;
char flag_mmc=0;

//RTC
volatile U32 rtc_tics;
volatile U16 rtc_milliseconds;
volatile U16 rtc_seconds;
unsigned char rtc_running=0;

//CAN
char state_can;
//_____________FUNCTIONS___________________________________________________________
void TCN_Config()
{
	TWBR=0xff;		//set frequency to 375 kHZ
	TWCR=0x44;
	TWSR=TWSR & 0xFC;
	TCN_raddr=0b10010001;
	TCN_waddr=0b10010000;
	//TWSR=TWSR | 0x01;
}

/*********************************************************************************
Write to accelerometer register
**********************************************************************************/
  void acc_write(void){

	TWCR = (1<<TWINT) | (1<<TWSTA) | (1<<TWEN); // send START
	while(!(TWCR & (1<<TWINT)));
	if ((TWSR & 0xF8)!=START)
		er=er+1;

	TWDR = I2C_slave<<1 | WRITE;			  //SLA2_W;	//load SLA_W
	TWCR = (1<<TWINT)|(1<<TWEN); //start transmission of address
	while(!(TWCR & (1<<TWINT)));
	if ((TWSR & 0xF8)!=MT_SLA_ACK)
		er=er+1;
	
	TWDR=reg[0];			//send register address
	TWCR=(1<<TWINT) | (1<<TWEN);
	while(!(TWCR & (1<<TWINT)));
	if ((TWSR & 0xF8)!=MT_DATA_ACK)
		er=er+1;
	
	TWDR=reg[1];				//send  data to register
	TWCR=(1<<TWINT) | (1<<TWEN);
	while(!(TWCR & (1<<TWINT)));
	if ((TWSR & 0xF8)!=MT_DATA_ACK)
		er=er+1;
	
	TWCR = (1<<TWINT) | (1<<TWEN) | (1<<TWSTO);

  }

/*****************************************************************************
read accelerometer register
*****************************************************************************/
void acc_read(void){

	unsigned long timeout=700000;	

	TWCR = (1<<TWINT) | (1<<TWSTA) | (1<<TWEN); // send START
	while(!(TWCR & (1<<TWINT)));
	if ((TWSR & 0xF8)!=START)
		er=er+1;

	TWDR = I2C_slave<<1 | WRITE;			  //load SLA_W
	TWCR = (1<<TWINT)|(1<<TWEN); //start transmission of address
	while(!(TWCR & (1<<TWINT)));
	if ((TWSR & 0xF8)!=MT_SLA_ACK)
		er=er+1;

	TWCR = (1<<TWINT) | (1<<TWEN) | (1<<TWSTO);

	TWCR = (1<<TWINT) | (1<<TWSTA) | (1<<TWEN); // send START
	while(!(TWCR & (1<<TWINT)));
	if ((TWSR & 0xF8)!=START)
		er=er+1;

	TWDR = I2C_slave<<1 | READ;			  //load SLA_R
	TWCR = (1<<TWINT)|(1<<TWEN); //start transmission of address
	while(!(TWCR & (1<<TWINT)));
	if ((TWSR & 0xF8)!=MR_SLA_ACK)
		er=er+1;
	
	
	TWCR = (1<<TWINT) | (1<<TWEN) ;
	while( (!(TWCR & (1<<TWINT))) && (timeout >0) )
			timeout--;
	xh=TWDR;					//receive X axis high byte
	if ((TWSR & 0xF8)!=MR_DATA_ACK)
		er=er+1;
	
	timeout=70000;
	
	TWCR = (1<<TWINT) | (1<<TWEN) ;
	while( (!(TWCR & (1<<TWINT)))&& (timeout >0) )
			timeout--;
	xl=TWDR;						//receive X axis low byte
	if ((TWSR & 0xF8)!=MR_DATA_ACK)
		er=er+1;

	timeout=700000;	

	TWCR = (1<<TWINT) | (1<<TWEN) ;
	while( (!(TWCR & (1<<TWINT))) && (timeout >0) )
			timeout--;
	yh=TWDR;					//receive Y axis high byte
	if ((TWSR & 0xF8)!=MR_DATA_ACK)
		er=er+1;
	
	timeout=70000;
	
	TWCR = (1<<TWINT) | (1<<TWEN) ;
	while( (!(TWCR & (1<<TWINT)))&& (timeout >0) )
			timeout--;
	yl=TWDR;						//receive Y axis low byte
	if ((TWSR & 0xF8)!=MR_DATA_ACK)
		er=er+1;

	TWCR = (1<<TWINT) | (1<<TWEN) ;
	while( (!(TWCR & (1<<TWINT))) && (timeout >0) )
			timeout--;
	zh=TWDR;					//receive Z axis high byte
	if ((TWSR & 0xF8)!=MR_DATA_ACK)
		er=er+1;
	
	timeout=70000;
	
	TWCR = (1<<TWINT) | (1<<TWEN) ;
	while( (!(TWCR & (1<<TWINT)))&& (timeout >0) )
			timeout--;
	zl=TWDR;						//receive X axis low byte
	if ((TWSR & 0xF8)!=MR_DATA_NACK)
		er=er+1;


	
	TWCR = (1<<TWINT) | (1<<TWEN) | (1<<TWSTO);
	

}


/*******************************************************************************
it's a simple delay
**********************************************************************************/
void Delay (unsigned long a) { while (--a!=0); }


/*
RTC interrupt initialization
*/
void rtc_int_init(void)
{
unsigned short i;

     asm volatile("cli");//Disable_interrupt();


    Timer8_clear();                 //-- Timer 2 cleared & initialized "OFF"
    for (i=0;i<0xFFFF;i++);         //-- Waiting to let the Xtal stabilize after a power-on
    Timer8_overflow_it_disable();   //-- Disable OCIE2A interrupt
    Timer8_compare_a_it_disable();  //-- Disable TOIE2 interrupt
    //-- Config: - CTC mode (mode 2, top=OCR2A)
    //--         - No output
    //--        (- Timer "OFF")
    Timer8_set_mode_output_a(TIMER8_COMP_MODE_NORMAL);
    Timer8_set_waveform_mode(TIMER8_WGM_CTC_OCR);


    //--- Asynchronous external clock 32,768 KHZ
        Timer8_2_external_osc();            //-- Init RTC clock
        Timer8_set_compare_a(33-1);         //-- MAGIC_NUMBER !
        //-- No prescaler & timer "ON"
        //-- Tic interval: ((1/32768)*MAGIC_NUMBER) sec = 1.00708008 msec
        Timer8_set_clock(TIMER8_CLKIO_BY_1);

    while(Timer8_2_update_busy());    //-- Wait for TCN2UB, OCR2UB and TCR2UB to be cleared

    Timer8_clear_compare_a_it();      //-- Clear Output_Compare Interrupt-flags
    Timer8_compare_a_it_enable();     //-- Enable Timer2 Output_Compare Interrupt

    //-- Time setting
    rtc_tics         = 0;
    rtc_milliseconds = 0;

    rtc_running = 1;
    asm volatile("sei");//Enable_interrupt();
}


//------------------------------------------------------------------------------
//  @fn ISR(TIMER2_COMP_vect)
//! Timer2 Output_Compare INTerrupt routine. Increment tics & the real-time
//! clock, the interrupt occurs once a milli second (or close).
//! @param  none
//!
//! @return  none
//!
//------------------------------------------------------------------------------


ISR(TIMER2_COMP_vect)
{
    //rtc_tics++;                     //-- Increments tics
    rtc_milliseconds++;             //-- Increments milli seconds

    if (rtc_milliseconds == 1000)
    {
        rtc_milliseconds = 0;
        rtc_seconds++;              //-- Increments seconds

        /*if (rtc_seconds == 60)
        {
            rtc_seconds = 0;
            rtc_minutes++;          //-- Increments minutes

            if (rtc_minutes == 60)
            {
                rtc_minutes = 0;
                rtc_hours++;        //-- Increments hours

                if (rtc_hours == 24)
                {
                    rtc_hours = 0;
                    rtc_days++;     //-- Increments days
                }
            }
        }*/
    }
}

/**********************************************************************
CAN - pin configuration and output test
***********************************************************************/
void can_test(void){
DDRD=DDRD & ~(1<<DDD6); //RD1 input
DDRD=DDRD | 1<<DDD5;    //TD1 output

DDRC=DDRC |  1<<DDC7;   //CAN_D(PC7)output
PORTC= PORTC & ~(1<<PC7);    //enable CAN

PORTD=PORTD | 1<<PD5;
if (PIND & 1<<PD6)
    state_can=0;
    else state_can=1;

PORTD=PORTD & ~(1<<PD5);
if (PIND & 1<<PD6)
    state_can=1;
    else state_can=0;

//DDRC=DDRC & ~(1<<DDC7); //CAN_D(PC7)output
PORTC= PORTC | 1<< PC7;	//disable CAN

PORTD=PORTD | 1<<PD5;

PORTD=PORTD & ~(1<<PD5);

PORTD=PORTD;
}

/***********************************************************************
mmc test
************************************************************************/
void mmc_test(void){
	if((initMMC() == MMC_SUCCESS))	// card found
						{
						memset(&mmc_buffer,0x00,128);

						mmcReadRegister (10, 16);
			    		mmc_buffer[7]=0;

			    		// Fill first Block (0) with 'A'
			   			memset(&mmc_buffer,'0',128);    //set breakpoint and trace mmc_buffer contents
						mmcWriteBlock(0);
			    		// Fill second Block (1)-AbsAddr 512 with 'B'
			    		memset(&mmc_buffer,'1',128);
						mmcWriteBlock(512);

			   			 // Read first Block back to buffer
			   			memset(&mmc_buffer,0x00,128);
			    		mmcReadBlock(0,512);
						memset(&mmc_buffer_test_1,'0',128);
			    		if(strncmp(&mmc_buffer[0], &mmc_buffer_test_1[0], 128))
					 		state_mmc=1;
							else state_mmc  = 0;

			    		memset(&mmc_buffer,0x00,128); //set breakpoint and trace mmc_buffer contents
			    		mmcReadBlock(512,512);
						memset(&mmc_buffer_test_1,'1',128);
			    		if(strncmp(&mmc_buffer[0], &mmc_buffer_test_1[0], 128))
							state_mmc=1;
							else state_mmc  = 0;
						memset(&mmc_buffer,0x00,128); //set breakpoint and trace mmc_buffer contents

						//if ( !state_mmc)	printstr_p(PSTR("\n\r\tMMC card success"));
						//	else printstr_p(PSTR("\n\r\tMMC card error"));
						//printstr_p(PSTR("\n\r\tRemove MMC card"));
						flag_mmc=1;
						}

}
/**********************************************************************
timer1 config
***********************************************************************/
void timer1c_config(void){
	asm volatile("cli");
	//CLKPR =0x80;	//set CLKPCE bit
	//CLKPR &=0xF0; //set division factor to 1
	Timer16_clear();				 //clear timer1 settings
	// Clock source: System Clock
	// Clock value: 8 000,000 kHz; t=125 nS
	// Mode: Normal top=FFFFh
#if 1
	Timer16_set_clock(TIMER16_CLKIO_BY_1);	//TIMER16_CLKIO_BY_1=1; clock source /1
	Timer16_set_waveform_mode(TIMER16_WGM_CTC_OCR) ;// TIMER16_WGM_NORMAL=0; set timer1 mode - Normal
	//Timer16_set_mode_output_c(TIMER16_COMP_MODE_TOGGLE); //TIMER16_COMP_MODE_TOGGLE=1; Toggle OC1C on Compare Match.
	//Timer16_set_compare_c(); 	//3 set clock value for period - to be CALCULATED
	Timer16_set_compare_a(5); //set clock value for period - to be CALCULATED
	DISP_ON;
	//Timer16_compare_c_it_enable(); 	//timer1c interrupt enable
	TIMSK1 |=  (1<<OCIE1A);
	asm volatile("sei");
#endif
}



ISR(TIMER1_COMPA_vect)
{
		LP_LOW;
		FLM_LOW;
		CP_HIGH;

//between 2 LP pulses send 160 pixels
		PORTA=(PORTA & 0xf3) | 0x03;	
		/*2)if(togle_pixel){
			PORTA=PORTA | 0x0F;	//send D3-D0=0000(blank)
			togle_pixel=0;
			}
			else{
				//PORTA=PORTA | 0x0F;	//send D3-D0=0000(blank)
				PORTA=PORTA & 0xF0;	//send D3-D0=0000(blank)
				togle_pixel=1;
				}
		*/
		CP_LOW;


		if(0 == --data_counter){
			
			data_counter = 40;
				    LP_HIGH;
				if(0 == --line_counter){
				    line_counter = 160;
					//DISP_OFF;
					}

				if(line_counter==160){//1
					       // start new frame
					      // for every new frame
					      FLM_HIGH;
						  //line=1;
				}

		}


	//	}



}

/*************************************************************************************
LCD write routine use arguments:
	nmb - number of rows to display
	x - vertical position on first row
	y - horisontal position on first row
	char -starting char(optional)
	length - string length displayed on single row
****************************************************************************************/
void lcd_update(int nmb,int x, int y, char ch,int length)
{
int cnt=0;//font bytes to be displayed
int pos=0;//char position to be written
int cx=x;//row
int cy=y;//column
char mych=ch;//starting char
int row_disp=0;//number of displayed rows
int row=x+80;//(row-x)/8=rows to be displayed
unsigned char pl;
unsigned char ph;

#if 0
	if(!flag_mmc){
	presense :		if (!(PING & 0x02))
					{
	protection:			if (!(PING & 0x01))
						{
							mmc_test();
						} else {
							//printstr_p(PSTR("\n\r\tMMC card write protected"));
							Delay(50000);
							goto protection;
							}
					}else {
						//printstr_p(PSTR("\n\r\tMMC card not present, please put MMC card"));
						Delay(50000);
						goto presense;
						}
		}
#endif

	//load string for each row on display
	//del1
	

	//display on LCD
	pos=0;
	for(int i=0; i<(3200); i+=20) {
	    // below is loop for every col
		//row_disp=0;	//new row of pixels to display
		//cy=y;//update column number
		//if (cnt==8)	//cnt needs to be updated regularly 
		//	cnt=0;
		for(int j=0; j<20; j++) {
				// get data
      		 pl = bitmap[i+j];
      		 ph = pl>>4;
     		 pl &= 0xF;
			CP_HIGH;
	    	PORTA=(PORTA & 0xF0) | ph;	//send higher 4 bits on D3-D0
		  	// clock CP
		   	CP_LOW;

		  	CP_HIGH;
		  	PORTA=(PORTA& 0xF0) | pl ;	//send lower 4 bits on D3-D0
	      	// clock CP
		  	CP_LOW;
			//del2
		 }
		    if(i)
		    {
		      LP_HIGH;
		      LP_LOW;
		    }
		    else
		    {
		      // start new frame
		      // for every new frame
		      FLM_HIGH;
		      LP_HIGH;
		      LP_LOW;
		      FLM_LOW;
		    }
  	}
}

/***************************************************************************************
****************************************************************************************/
void write_string(int row,int string_count,unsigned char * string,int inv){
		
		int pos=0;
		for(int count=0;count<string_count;count++){
			LCDWriteChar(0,0,row,pos,string[count],inv);
			pos=pos+1;
			}
}
/**************************************************************************************
ADC configuration
***************************************************************************************/
void init_adc(void){

  #if 0
	//measure X axis movement
  PORTF = PORTF | 1<<PF0;   // ADC1 to high
  PORTF = PORTF & ~(1<<PF1);// ADC2 to low
  PORTF = PORTF |1<<PF2;// ADC3 to  high(enable pullup)
  PORTF = PORTF |1<<PF3;// ADC4 to high(enable pullup)

  DDRF=DDRF | 1 <<DDF0; 	//ADC1 output
  DDRF=DDRF | 1 <<DDF1; 	//ADC2 output
  DDRF=DDRF & ~(1<<DDF2); 	//ADC3 input
  DDRF=DDRF & ~(1<<DDF3); 	//ADC4 input
  #endif

  #if 1
  //measure Y axis movement
  PORTF = PORTF | 1<<PF0;   // ADC1 to high (enable pullup)
  PORTF = PORTF | 1<<PF1;	// ADC2 to high(enable pullup)
  PORTF = PORTF | 1<<PF2;	// ADC3 to  high
  PORTF = PORTF & ~(1<<PF3);// ADC4 to low

  DDRF=DDRF & ~(1<<DDF0); 	//ADC1 input
  DDRF=DDRF & ~(1<<DDF1); 	//ADC2 input
  DDRF=DDRF | 1<<DDF2; 		//ADC3 output
  DDRF=DDRF | 1<<DDF3; 		//ADC4 output
  #endif



  ADMUX  &= ~((1<<REFS1)|(1<<REFS0)); //external VREF
  // ADMUX  &= ~(1<<REFS1);	//Enable_avcc_as_vref
  // ADMUX  |=  (1<<REFS0) ;

   ADMUX  &= ~(1<<ADLAR);	//clear left adjust

   ADMUX  &= ~(0x1F<<MUX0); //clear channel selection
   ADMUX |= (0<<MUX0);	//channel ADC1 select

	ADCSRA &= ~(0x07<<ADPS0);		 //clear prescaler
 	ADCSRA |= (ADC_PRESCALER<<ADPS0); //select prescaler
}



//_______________________MAIN PROGRAM______________________________________
int main(void){

		data_counter=40;
		line_counter=160;
		//initialize LCD
		InitLCD();

		//LCD on
		 LCD_Off();
		 LCD_On();
	#if 1
		//RTC INIT
		timer1c_config();	//Timer 1 configuration
		init_adc();			//ADC configuration
		rtc_int_init();		//RealTimeClock configuration
	
		//	TEST CAN
		can_test();
		//Timer16_compare_c_it_enable(); 	//timer1c interrupt enable
	#endif

	#if 1
		//1)Init AVR I2C interface 
		TCN_Config();//use my function insteadI2C_InitMaster(375000);	
		//2)INIT Accelerometer
		// are any commands to0 configure are required or just wake-up??????????????
		//2.1)register 14h
		reg[0]=0x14;
		old_value=I2C_MasterRead (I2C_slave, &read_reg, 1);
		reg[1]=old_value & 0b11100000;
		acc_write();//use my function instead I2C_MasterWrite (I2C_slave,reg,2);//for write command - 1 or 2 bytes are required
		//2.2)register 15h
		reg[0]=0x15;
		reg[1]=0x01;
		acc_write();//use my function instead I2C_MasterWrite(I2C_slave,reg,2);//for write command - 1 or 2 bytes are required
		//3)read accelerator values
		reg[0]=0x02;//data register address
		acc_read();//	use my function instead I2C_Transfer (I2C_slave,reg,6,WRITETHENREAD,1);
    #endif
	//	Delay(1000);


		// clear
		// LCDWriteBlank();

#if 1
		write_string(0,12,board_name,0);
		write_string(8,4,menu,0);
		write_string(16,14,test_ext,0);
		write_string(24,8,test_can,0);
		write_string(32,8,test_mmc,0);
		write_string(40,16,test_acc,0);
#endif
		while(1){

		//lcd_update(38,4,'h',6);
		  ADCSRA |=  (1<<ADEN); 	//enable ADC
		  ADCSRA &= ~(1<<ADATE); 	//start conversion
		  ADCSRA |=  (1<<ADSC) ;
		  while(!(ADCSRA  &  (1<<ADIF))); // wait until conversion complete
		  myy=ADC;
		  ADCSRA |=  (1<<ADIF); //clear ADIF flag
		
			//CP_LOW;
			//CP_HIGH;	
		  //lcd_update(10,0,0,'a',12);
		
		//ITEM selection
		#if 1
		if(myy > 860){//850
			choice=1;
			//LCDWriteBlank();
			write_string(0,12,board_name,1);
			write_string(8,4,menu,0);
			write_string(16,14,test_ext,0);
			write_string(24,8,test_can,0);
			write_string(32,8,test_mmc,0);
			write_string(40,16,test_acc,0);
			}
			else if (myy>830){//800
				choice=2;
				LCDWriteBlank();
				write_string(0,12,board_name,0);
				write_string(8,4,menu,1);
				write_string(16,14,test_ext,0);
				write_string(24,8,test_can,0);
				write_string(32,8,test_mmc,0);
				write_string(40,16,test_acc,0);
						}
			else if (myy>810){//750
				choice=3;
				//LCDWriteBlank();
				write_string(0,12,board_name,0);
				write_string(8,4,menu,0);
				write_string(16,14,test_ext,1);
				write_string(24,8,test_can,0);
				write_string(32,8,test_mmc,0);
				write_string(40,16,test_acc,0);
				}
			else if (myy>790){//670
				choice=4;
				//LCDWriteBlank();
				write_string(0,12,board_name,0);
				write_string(8,4,menu,0);
				write_string(16,14,test_ext,0);
				write_string(24,8,test_can,1);
				write_string(32,8,test_mmc,0);
				write_string(40,16,test_acc,0);
				}
			else if (myy>770){//650
				choice=5;
				//LCDWriteBlank();
				write_string(0,12,board_name,0);
				write_string(8,4,menu,0);
				write_string(16,14,test_ext,0);
				write_string(24,8,test_can,0);
				write_string(32,8,test_mmc,1);
				write_string(40,16,test_acc,0);
				}
			else if (myy>730){//600
				choice=6;
				//LCDWriteBlank();//write_string(0,12,board_name,0);
				write_string(0,12,board_name,0);
				write_string(8,4,menu,0);
				write_string(16,14,test_ext,0);
				write_string(24,8,test_can,0);
				write_string(32,8,test_mmc,0);
				write_string(40,16,test_acc,1);
				}
			else if (myy>550){
				choice=7;
				}
			else if (myy>500){
				choice=8;
				}
			else if (myy>450){
				choice=9;
				}
			else if (myy>400){
				choice=10;
				}
			else if (myy>350){
				choice=11;
				}
			
			//lcd_update(10,0,0,'a',12);

/*
			switch(choice)	{
			case 1:	lcd_update(10,0,0,'a',12);
			break;

			case 2:	lcd_update(10,15,0,'b',12);
			break;

			case 3:	lcd_update(10,30,0,'c',12);
			break;

			case 4:	lcd_update(1,45,0,'d',12);
			break;

			case 5:	lcd_update(1,60,0,'e',12);
			break;

			case 6:	lcd_update(1,75,0,'f',5);
			break;

			case 7:	lcd_update(1,90,0,'g',5);
			break;

			case 8:	lcd_update(1,105,0,'h',5);
			break;

			case 9:	lcd_update(6,120,0,'i',10);
			break;

			case 10:lcd_update(6,135,0,'j',10);
			break;

			case 11:lcd_update(6,150,0,'k',10);
			break;
			}*/

			#endif
	}

}
