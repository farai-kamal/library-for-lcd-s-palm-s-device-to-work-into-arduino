// mmc.c : MultiMediaCard functions: init, read, write ...
//
// Rolf Freitag 5/2003
//

// MMC Lib
#ifndef _MMCLIB_C
#define _MMCLIB_C
//---------------------------------------------------------------------
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include <inttypes.h>

//#include "header.h"
#include "mmc.h"
#include "spi_drv.h"
//#include "bits.h"
#include <string.h>

// macro defines // PORTC2 Card Select// Card Deselect

#define CS_LOW()  PORTG= PORTG & ~(1<<PG2)	
#define CS_HIGH() PORTG= PORTG | (1<<PG2)
//#define DUMMY 0xff

#define MSK_SPI_MODE      	0x0C
#define MSK_MSTR            0x10
#define SPI_MASTER_MODE_0 (MSK_MSTR)
#define SPI_MASTER_MODE_1 (MSK_MSTR|0x04)
#define SPI_MASTER_MODE_2 (MSK_MSTR|0x08)
#define SPI_MASTER_MODE_3 (MSK_MSTR|0x0C)
#define MSK_SPI_SPR1  0x02
#define MSK_SPI_SPR0  0x01
//#define SPI_RATE_0        0x00    /* Fper / 2 */
#define SPI_RATE_1        0x00    /* Fper / 4 */
//#define SPI_RATE_2        0x02    /* Fper / 8 */
#define SPI_RATE_3        0x01    /* Fper / 16 */
//#define SPI_RATE_4        0x80    /* Fper / 32 */
#define SPI_RATE_5        0x02    /* Fper / 64 */
#define SPI_RATE_6        0x03    /* Fper / 128 */

char mmcGetResponse(void);
char mmcGetXXResponse(const char resp);
char mmcCheckBusy(void);
void initSPI (void);


// Buffer for mmc i/o for data and registers
char mmc_buffer[128] ;	

// setup usart1 in spi mode
void initSPI (void)
{ 
		
	DDRG = DDRG | 1<<DDG2;  //CS (PG2)
	DDRG = DDRG & ~((1<<DDG0)|(1<<DDG1));  //WP(PD0);CP(PD1)- 0b11111101

	  // Configure SPI1 pins: SCK, MISO and MOSI
	  //TRISDbits.TRISD4=0; //MOSI
      //TRISDbits.TRISD5=1; //MISO
	  //TRISDbits.TRISD6=0; //SCK

		/* Set MOSI and SCK output, all others input */
	//	DDR_SPI = (1<<DD_MOSI)|(1<<DD_SCK);
		/* Enable SPI, Master, set clock rate fck/16 */
	//	SPCR = (1<<SPE)|(1<<MSTR)|(1<<SPR0);

	


	SPCR &= ~(MSK_SPI_MASTER_MODE|MSK_SPI_MODE ); 
	SPCR |= SPI_MASTER_MODE_0;
	DDRB |= (1<<DDB2)|(1<<DDB1) ;//enable MOSI and SCK
	

	SPCR &= ~(MSK_SPI_SPR1|MSK_SPI_SPR0);
	SPCR |= SPI_RATE_3;
	
	SPCR |= MSK_SPI_ENABLE;

	

}


// Initialisieren
char initMMC (void)
{

  //raise SS and MOSI for 80 clock cycles
  //SendByte(0xff) 10 times with SS high
  //RAISE SS
  int i;
  int flag;
  char response=0x01;

  // Start iniMMC......
  initSPI();
  //initialization sequence on PowerUp
  CS_HIGH();
  for(i=0;i<=9;i++)
    spiSendByte(0xff);
  CS_LOW();
  //Send Command 0 to put MMC in SPI mode
  mmcSendCmd(0x00,0,0x95);
  //Now wait for READY RESPONSE
  if(mmcGetResponse()!=0x01);
		flag=1;
  // debug_printf("no responce");

  while(response==0x01)
  {
   CS_HIGH();
   spiSendByte(0xff);
   CS_LOW();
   mmcSendCmd(0x01,0x00,0xff);
   response=mmcGetResponse();
  }
  CS_HIGH();
  spiSendByte(0xff);

  return MMC_SUCCESS;
}



// Ti added mmc Get Responce
char mmcGetResponse(void)
{
  //Response comes 1-8bytes after command
  //the first bit will be a 0
  //followed by an error code
  //data will be 0xff until response
  int i=0;

  char response;

  while(i<=64)
  {
   response=spiSendByte(0xff);
   if(response==0x00)break;
   if(response==0x01)break;
   i++;
  }
  return response;
}

char mmcGetXXResponse(const char resp)
{
  //Response comes 1-8bytes after command
  //the first bit will be a 0
  //followed by an error code
  //data will be 0xff until response
  int i=0;

  char response;

  while(i<=500)
  {
   response=spiSendByte(0xff);
   if(response==resp)break;
   i++;
  }
  return response;
}

char mmcCheckBusy(void)
{
  //Response comes 1-8bytes after command
  //the first bit will be a 0
  //followed by an error code
  //data will be 0xff until response
  int i=0;

  char response;
  char rvalue;
  while(i<=64)
  {
   response=spiSendByte(0xff);
   response &= 0x1f;
   switch(response)
    {
     case 0x05: rvalue=MMC_SUCCESS;break;
     case 0x0b: return(MMC_CRC_ERROR);
     case 0x0d: return(MMC_WRITE_ERROR);
     default:
	      rvalue = MMC_OTHER_ERROR;
	      break;
    }
   if(rvalue==MMC_SUCCESS)break;
    i++;
  }
  i=0;
  do
  {
   response=spiSendByte(0xff);
   i++;
  }while(response==0);
  return response;
}

// The card will respond with a standard response token followed by a data
// block suffixed with a 16 bit CRC.
// Ti Modification: long int -> long ; int -> long
char mmcReadBlock(const unsigned long address, const unsigned long count)
{
  unsigned long i = 0;
  char rvalue = MMC_RESPONSE_ERROR;

  // Set the block length to read
  if (mmcSetBlockLength (count) == MMC_SUCCESS)	// block length could be set
    {
      // SS = LOW (on)
      CS_LOW ();
      // send read command MMC_READ_SINGLE_BLOCK=CMD17
      mmcSendCmd (17,address, 0xFF);
      // Send 8 Clock pulses of delay, check if the MMC acknowledged the read block command
      // it will do this by sending an affirmative response
      // in the R1 format (0x00 is no errors)
      if (mmcGetResponse() == 0x00)
	{
	  // now look for the data token to signify the start of
	  // the data
	  if (mmcGetXXResponse(MMC_START_DATA_BLOCK_TOKEN) == MMC_START_DATA_BLOCK_TOKEN)
	    {
	      // clock the actual data transfer and receive the bytes; spi_read automatically finds the Data Block
	      for (i = 0; i < 512; i++)
			if(i<128)
				mmc_buffer[i] = spiSendByte(0xff);	// is executed with card inserted
				else mmc_buffer[0] = spiSendByte(0xff);	// is executed with card inserted
	      // get CRC bytes (not really needed by us, but required by MMC)
	      spiSendByte(0xff);
	      spiSendByte(0xff);
	      rvalue = MMC_SUCCESS;
	    }
	  else
	    {
	      // the data token was never received
	      rvalue = MMC_DATA_TOKEN_ERROR;	// 3
	    }
	}
      else
	{
	  // the MMC never acknowledge the read command
	  rvalue = MMC_RESPONSE_ERROR;	// 2
	}
    }
  else
    {
      rvalue = MMC_BLOCK_SET_ERROR;	// 1
    }
  CS_HIGH ();
  spiSendByte(0xff);
  return rvalue;
}				// mmc_read_block

//---------------------------------------------------------------------
// Ti Modification: long int -> long
char mmcWriteBlock (const unsigned long address)
{
  unsigned long i = 0;
  char rvalue = MMC_RESPONSE_ERROR;	// MMC_SUCCESS;
  //char c = 0x00;

  // Set the block length to read
  if (mmcSetBlockLength (512) == MMC_SUCCESS)	// block length could be set
    {
      // SS = LOW (on)
      CS_LOW ();
      // send write command
      mmcSendCmd (24,address, 0xFF);

      // check if the MMC acknowledged the write block command
      // it will do this by sending an affirmative response
      // in the R1 format (0x00 is no errors)
      if (mmcGetXXResponse(MMC_R1_RESPONSE) == MMC_R1_RESPONSE)
	{
	  spiSendByte(0xff);
	  // send the data token to signify the start of the data
	  spiSendByte(0xfe);
	  // clock the actual data transfer and transmitt the bytes
	  for (i = 0; i < 512; i++)
		if(i<128)
		    spiSendByte(mmc_buffer[i]);	// mmc_buffer[i];       Test: i & 0xff
			else spiSendByte(mmc_buffer[0]);
	  // put CRC bytes (not really needed by us, but required by MMC)
	  spiSendByte(0xff);
	  spiSendByte(0xff);
	  // read the data response xxx0<status>1 : status 010: Data accected, status 101: Data
	  //   rejected due to a crc error, status 110: Data rejected due to a Write error.
          mmcCheckBusy();
	}
      else
	{
	  // the MMC never acknowledge the write command
	  rvalue = MMC_RESPONSE_ERROR;	// 2
	}
    }
  else
    {
      rvalue = MMC_BLOCK_SET_ERROR;	// 1
    }
  // give the MMC the required clocks to finish up what ever it needs to do
  //  for (i = 0; i < 9; ++i)
  //    spiSendByte(0xff);

  CS_HIGH ();
  // Send 8 Clock pulses of delay.
  spiSendByte(0xff);
  return rvalue;
}				// mmc_write_block





//---------------------------------------------------------------------
void mmcSendCmd (const char cmd, unsigned long data, const char crc)
{
  char frame[6];
  char temp;
  int i;

  frame[0]=(cmd|0x40);
  for(i=3;i>=0;i--){
    temp=(char)(data>>(8*i));
    frame[4-i]=(temp);
  }
  frame[5]=(crc);
  for(i=0;i<6;i++)
    spiSendByte(frame[i]);
}


//--------------- set blocklength 2^n ------------------------------------------------------
// Ti Modification: long int-> long
char mmcSetBlockLength (const unsigned long blocklength)
{
  //char rValue = MMC_TIMEOUT_ERROR;
  //char i = 0;

  // SS = LOW (on)
  CS_LOW ();

  // Set the block length to read
  //MMC_SET_BLOCKLEN =CMD16
  mmcSendCmd(16, blocklength, 0xFF);

  // get response from MMC - make sure that its 0x00 (R1 ok response format)
  if(mmcGetResponse()!=0x00);

  CS_HIGH ();

  // Send 8 Clock pulses of delay.
  spiSendByte(0xff);

  return MMC_SUCCESS;
}				// block_length

//TI added substitution routine for spi_read and spi_write
unsigned char spiSendByte( unsigned char n_data)
{
  	/* Start transmission */
	SPDR = n_data;
	/* Wait for transmission complete */
	while(~SPSR & (1<<SPIF));
	n_data = SPDR;
	// Return the byte read from the SPI bus
	return n_data;


}


// Reading the contents of the CSD and CID registers in SPI mode is a simple
// read-block transaction.
char mmcReadRegister (const char cmd_register, const unsigned char length)
{
  char uc = 0;
  char rvalue = MMC_TIMEOUT_ERROR;
//  char i = 0;

  if (mmcSetBlockLength (length) == MMC_SUCCESS)
    {
      CS_LOW ();
      // CRC not used: 0xff as last byte
      mmcSendCmd(cmd_register, 0x000000, 0xff);

      // wait for response
      // in the R1 format (0x00 is no errors)
      if (mmcGetResponse() == 0x00)
	{
	 if (mmcGetXXResponse(0xfe)== 0xfe)
	    for (uc = 0; uc < length; uc++)
	      mmc_buffer[uc] = spiSendByte(0xff);
	  // get CRC bytes (not really needed by us, but required by MMC)
	  spiSendByte(0xff);
	  spiSendByte(0xff);
	}
      else
	rvalue = MMC_RESPONSE_ERROR;
      // CS = HIGH (off)
      CS_HIGH ();

      // Send 8 Clock pulses of delay.
      spiSendByte(0xff);
    }
  CS_HIGH ();
  return rvalue;
}				// mmc_read_register

//---------------------------------------------------------------------
#endif /* _MMCLIB_C */
