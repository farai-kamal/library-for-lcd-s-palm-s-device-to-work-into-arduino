/*************************************************************************
 *
*    Used with ICCARM and AARM.
 *
 *    (c) Copyright IAR Systems 2007
 *
 *    File name   : smb380_drv.c
 *    Description : SMB380 acceleration sensor driver (I2C data mode)
 *
 *    History :
 *    1. Date        : 13, February 2008
 *       Author      : Stanimir Bonev
 *       Description : Create
 *
 *
 *    $Revision: 18137 $
 **************************************************************************/
#include "smb380_drv.h"
#include "arm_comm.h"
//#include "header.h"
/*************************************************************************
 * Function Name: SMB380_Init
 * Parameters: none
 *
 * Return: SMB380_Status_t
 *
 * Description: SMB380 init
 *
 *************************************************************************/
SMB380_Status_t SMB380_Init (void)
{
}

/*************************************************************************
 * Function Name: SMB380_GetID
 * Parameters: none
 *
 * Return: SMB380_Status_t
 *
 * Description: SMB380 get chip ID and revision
 *
 *************************************************************************/
SMB380_Status_t SMB380_GetID (pInt8U pChipId, pInt8U pRevision)
{

}

/*************************************************************************
 * Function Name: SMB380_Init
 * Parameters: none
 *
 * Return: SMB380_Status_t
 *
 * Description: SMB380 init
 *
 *************************************************************************/
SMB380_Status_t SMB380_GetData (pSMB380_Data_t pData)
{
}

/*************************************************************************
 * Function Name: SMB380_SetMode
 * Parameters: Boolean Permanent, SMB380_Range_t Range,
 *             SMB380_Bandwidth_t Bandwidth
 *
 * Return: SMB380_Status_t
 *
 * Description: SMB380 set operation mode
 *
 *************************************************************************/
SMB380_Status_t SMB380_SetMode(Boolean Permanent, SMB380_Range_t Range,
                               SMB380_Bandwidth_t Bandwidth)
{
}

/*************************************************************************
 * Function Name: SMB380_GetMode
 * Parameters: SMB380_Range_t * pRange, SMB380_Bandwidth_t * pBandwidth
 *
 * Return: SMB380_Status_t
 *
 * Description: SMB380 get operation mode
 *
 *************************************************************************/
SMB380_Status_t SMB380_GetMode(SMB380_Range_t * pRange,
                               SMB380_Bandwidth_t * pBandwidth)
{
}

/*************************************************************************
 * Function Name: SMB380_SetUserData
 * Parameters: Boolean Permanent, Int16U Data
 *
 * Return: SMB380_Status_t
 *
 * Description: SMB380 set operation mode
 *
 *************************************************************************/
SMB380_Status_t SMB380_SetUserData(Boolean Permanent, Int16U Data)
{
}

/*************************************************************************
 * Function Name: SMB380_GetUserData
 * Parameters: pInt16U pData
 *
 * Return: SMB380_Status_t
 *
 * Description: SMB380 get operation mode
 *
 *************************************************************************/
SMB380_Status_t SMB380_GetUserData(pInt16U pData)
{
}

/*************************************************************************
 * Function Name: SMB380_Set_T_Data
 * Parameters: Boolean Permanent, Int16U Offset, Int8U Gain
 *
 * Return: SMB380_Status_t
 *
 * Description: SMB380 set Temperature's Offset and gain
 *
 *************************************************************************/
SMB380_Status_t SMB380_Set_T_Data(Boolean Permanent, Int16U Offset, Int8U Gain)
{
}

/*************************************************************************
 * Function Name: SMB380_Get_T_Data
 * Parameters: pInt16U pData
 *
 * Return: SMB380_Status_t
 *
 * Description: SMB380 get Temperature's Offset and gain
 *
 *************************************************************************/
SMB380_Status_t SMB380_Get_T_Data(pInt16U pOffset, pInt8U pGain)
{
}

/*************************************************************************
 * Function Name: SMB380_Set_AccX_Data
 * Parameters: Boolean Permanent, Int16U Offset, Int8U Gain
 *
 * Return: SMB380_Status_t
 *
 * Description: SMB380 set AccX's Offset and gain
 *
 *************************************************************************/
SMB380_Status_t SMB380_Set_AccX_Data(Boolean Permanent, Int16U Offset, Int8U Gain)
{
}

/*************************************************************************
 * Function Name: SMB380_Get_AccX_Data
 * Parameters: pInt16U pData
 *
 * Return: SMB380_Status_t
 *
 * Description: SMB380 get AccX's Offset and gain
 *
 *************************************************************************/
SMB380_Status_t SMB380_Get_AccX_Data(pInt16U pOffset, pInt8U pGain)
{
}

/*************************************************************************
 * Function Name: SMB380_Set_AccY_Data
 * Parameters: Boolean Permanent, Int16U Offset, Int8U Gain
 *
 * Return: SMB380_Status_t
 *
 * Description: SMB380 set AccY's Offset and gain
 *
 *************************************************************************/
SMB380_Status_t SMB380_Set_AccY_Data(Boolean Permanent, Int16U Offset, Int8U Gain)
{
}

/*************************************************************************
 * Function Name: SMB380_Get_AccY_Data
 * Parameters: pInt16U pData
 *
 * Return: SMB380_Status_t
 *
 * Description: SMB380 get AccY's Offset and gain
 *
 *************************************************************************/
SMB380_Status_t SMB380_Get_AccY_Data(pInt16U pOffset, pInt8U pGain)
{
}

/*************************************************************************
 * Function Name: SMB380_Set_AccZ_Data
 * Parameters: Boolean Permanent, Int16U Offset, Int8U Gain
 *
 * Return: SMB380_Status_t
 *
 * Description: SMB380 set AccZ's Offset and gain
 *
 *************************************************************************/
SMB380_Status_t SMB380_Set_AccZ_Data(Boolean Permanent, Int16U Offset, Int8U Gain)
{
}

/*************************************************************************
 * Function Name: SMB380_Get_AccZ_Data
 * Parameters: pInt16U pData
 *
 * Return: SMB380_Status_t
 *
 * Description: SMB380 get AccZ's Offset and gain
 *
 *************************************************************************/
SMB380_Status_t SMB380_Get_AccZ_Data(pInt16U pOffset, pInt8U pGain)
{
}

/*************************************************************************
 * Function Name: SMB380_Set_AnyMotion_Data
 * Parameters: Boolean Permanent, Int8U Duration, Int8U Threshold
 *
 * Return: SMB380_Status_t
 *
 * Description: SMB380 set any motion's duration and threshold
 *
 *************************************************************************/
SMB380_Status_t SMB380_Set_AnyMotion_Data(Boolean Permanent, Int8U Duration, Int8U Threshold)
{
}

/*************************************************************************
 * Function Name: SMB380_Get_AnyMotion_Data
 * Parameters: pInt8U pDuration, pInt8U pThreshold
 *
 * Return: SMB380_Status_t
 *
 * Description: SMB380 get any motion's duration and threshold
 *
 *************************************************************************/
SMB380_Status_t SMB380_Get_AnyMotion_Data(pInt8U pDuration, pInt8U pThreshold)
{
}

/*************************************************************************
 * Function Name: SMB380_Set_LG_Data
 * Parameters: Boolean Permanent, Int8U Duration,
 *             Int8U Hysteresis, Int8U Threshold
 *
 * Return: SMB380_Status_t
 *
 * Description: SMB380 set low-g duration, hysteresis, threshold and
 * debouncing
 *
 *************************************************************************/
SMB380_Status_t SMB380_Set_LG_Data(Boolean Permanent, Int8U Duration,
                                   Int8U Hysteresis, Int8U Threshold,
                                   Int8U Debouncing)
{
}

/*************************************************************************
 * Function Name: SMB380_Get_LG_Data
 * Parameters: pInt8U pDuration, pInt8U pThreshold
 *
 * Return: SMB380_Status_t
 *
 * Description: SMB380 get low-g duration, hysteresis, threshold and
 * debouncing
 *
 *************************************************************************/
SMB380_Status_t SMB380_Get_LG_Data(pInt8U * pDuration, pInt8U * pHysteresis,
                                   pInt8U * pThreshold, pInt8U * pDebouncing)
{
}

/*************************************************************************
 * Function Name: SMB380_Set_LG_Data
 * Parameters: Boolean Permanent, Int8U Duration,
 *             Int8U Hysteresis, Int8U Threshold
 *
 * Return: SMB380_Status_t
 *
 * Description: SMB380 set high-g duration, hysteresis, threshold and
 * debouncing
 *
 *************************************************************************/
SMB380_Status_t SMB380_Set_HG_Data(Boolean Permanent, Int8U Duration,
                                   Int8U Hysteresis, Int8U Threshold,
                                   Int8U Debouncing)
{
}

/*************************************************************************
 * Function Name: SMB380_Get_LG_Data
 * Parameters: pInt8U pDuration, pInt8U pThreshold
 *
 * Return: SMB380_Status_t
 *
 * Description: SMB380 get high-g duration, hysteresis, threshold and
 *  debouncing
 *
 *************************************************************************/
SMB380_Status_t SMB380_Get_HG_Data(pInt8U * pDuration, pInt8U * pHysteresis,
                                   pInt8U * pThreshold, pInt8U *pDebouncing)
{
}

/*************************************************************************
 * Function Name: SMB380_SeftTest0
 * Parameters: pInt8U * pResult
 *
 * Return: SMB380_Status_t
 *
 * Description: SMB380 run seft test 0
 *
 *************************************************************************/
SMB380_Status_t SMB380_SeftTest0(pInt8U * pResult)
{
}

/*************************************************************************
 * Function Name: SMB380_SeftTest1
 * Parameters: pInt8U * pResult
 *
 * Return: SMB380_Status_t
 *
 * Description: SMB380 run seft test 1
 *
 *************************************************************************/
SMB380_Status_t SMB380_SeftTest1(pInt8U * pResult)
{
}

/*************************************************************************
 * Function Name: SMB380_Sleep
 * Parameters: pInt8U * pResult
 *
 * Return: SMB380_Status_t
 *
 * Description: SMB380 enter/exit to/from sleep mode
 *
 *************************************************************************/
SMB380_Status_t SMB380_Sleep(Boolean Sleep)
{
}

/*************************************************************************
 * Function Name: SMB380_SW_Reset
 * Parameters: none
 *
 * Return: SMB380_Status_t
 *
 * Description: SMB380 software reset
 *
 *************************************************************************/
SMB380_Status_t SMB380_SW_Reset(void)
{
}

/*************************************************************************
 * Function Name: SMB380_UpdateImage
 * Parameters: none
 *
 * Return: SMB380_Status_t
 *
 * Description: SMB380 force to update registers' image
 *
 *************************************************************************/
SMB380_Status_t SMB380_UpdateImage(void)
{
}

/*************************************************************************
 * Function Name: SMB380_NewDataIntr
 * Parameters: none
 *
 * Return: SMB380_Status_t
 *
 * Description: SMB380 enable/disable new data interrupt
 *
 *************************************************************************/
SMB380_Status_t SMB380_NewDataIntr(Boolean Enable, void * CallbackFnc)
{
}

/*************************************************************************
 * Function Name: SMB380_AlertIntr
 * Parameters: none
 *
 * Return: SMB380_Status_t
 *
 * Description: SMB380 enable/disable alert interrupt
 *
 *************************************************************************/
SMB380_Status_t SMB380_AlertIntr(Boolean Enable, void * CallbackFnc)
{
}

/*************************************************************************
 * Function Name: SMB380_AnyMotionIntr
 * Parameters: none
 *
 * Return: SMB380_Status_t
 *
 * Description: SMB380 enable/disable any motion interrupt
 *
 *************************************************************************/
SMB380_Status_t SMB380_AnyMotionIntr(Boolean Enable, void * CallbackFnc)
{
}

/*************************************************************************
 * Function Name: SMB380_LG_Intr
 * Parameters: none
 *
 * Return: SMB380_Status_t
 *
 * Description: SMB380 enable/disable low-g interrupt
 *
 *************************************************************************/
SMB380_Status_t SMB380_LG_Intr(Boolean Enable, void * CallbackFnc)
{
}

/*************************************************************************
 * Function Name: SMB380_HG_Intr
 * Parameters: none
 *
 * Return: SMB380_Status_t
 *
 * Description: SMB380 enable/disable high-g interrupt
 *
 *************************************************************************/
SMB380_Status_t SMB380_HG_Intr(Boolean Enable, void * CallbackFnc)
{
}
