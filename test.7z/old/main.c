//_____ I N C L U D E S ________________________________________________________
#include "lib_mcu/compiler.h"
#include <avr/io.h>
#include <avr/interrupt.h>

#include "timer16_drv.h"
#include "timer8_drv.h"

#include "lcd.h"  //user defined
#include "mmc.h"  //user-defined

#include "i2c_drv.h"
#include "smb380_drv.h"
#include <util/twi.h>		/* Note [1] */

#define ADC_PRESCALER 0x06

//_____________DEFINITIONS___________________________________________________________
//LCD 

char menu[10]="      MENU";
char success[7]="SUCCESS";
char error[5]="ERROR";
char board_name[16]= "    AVR-TLCD CAN  ";
char test_mmc[8]  = "Test MMC";
char put[19]="put card/remove ext";
char protect[19]= "MMC write protected";
char success_mmc[11]="SUCCESS MMC";
char error_mmc[9]="ERROR MMC";
char test_can[8]  = "Test CAN";
char success_can[11]="SUCCESS CAN";
char error_can[9]="ERROR CAN";
char test_acc[16]  = "Test accelerator";
int bl_en=0;
int bl_on=0;
int bl_rel=1;//backlight item is released
char backlight[13]  = "LCD backlight";
char state[6]="State:";
char acc[3]="Acc";
//char zero[4]="";
char test_ext1[14]  = "Test extension";
char success_ext[11]="SUCCESS ext";
char ZP[9]="    to   ";
unsigned char bit_state, card_state = 0;
unsigned char can_timeout;
int timer_ = 100;
char WORK = 0;

/*
char zb[9]="zeroB ext";
char zc[9]="zeroC ext";
char zd[9]="zeroD ext";
char zg[9]="zeroG ext";
char ze[9]="zeroE ext";*/
char precision=1;

extern unsigned char test_ext, P1, B1, P2, B2, X;;

//Accelerator
/*
#define START	0x08
#define MT_SLA_ACK	0x18
#define MT_SLA_NACK	0x20
#define MT_DATA_ACK 0x28
#define MT_DATA_NACK 0x30
#define MR_SLA_ACK	0x40
#define MR_DATA_ACK 0x50
#define MR_DATA_NACK 0x58
#define SLA_W	0b10010000
#define SLA_R	0b10010001
#define SLA2_W	0b10010010
#define SLA2_R	0b10010011
#define START	0x08
#define MT_SLA_ACK	0x18
#define MT_SLA_NACK	0x20
#define MT_DATA_ACK 0x28
#define MT_DATA_NACK 0x30
#define MR_SLA_ACK	0x40
#define MR_DATA_ACK 0x50
#define MR_DATA_NACK 0x58
*/
unsigned char old_value=0;
unsigned long sum_adc=0;	//sum of last 50-100 mesurements
int meas_cnt=0;
unsigned int adc_arr[8];
unsigned char flag_acc=0;
unsigned char dis_acc=1;	//SPP
unsigned char reg[2];
unsigned char	read_reg=0;

/*
union adc_data
{ 
  unsigned char data[2];
  signed short result;
};
typedef union adc_data adc_data;
adc_data myadc;

*/

unsigned char rtc_error=0;

unsigned char TCN_Conf;
unsigned int TCN_Data;
unsigned char TCN_raddr,TCN_waddr;

unsigned char newx=0;newy=0,newz=0;
int er=0;
U8 xl=0,xh=0,yl=0,yh=0,zl=0,zh=0;

unsigned int sym;
signed short int accx=0;
signed short int accy=0;
signed short int accz=0;
char digitx[4];
char digity[4];
char digitz[4];

extern volatile int	  I2CState;
extern LPC_I2C_Msg_t	  I2CMsg;



/*
uint16_t temph,templ,temp;
double tempwr;	
double tempwr2;*/

 unsigned long timeout=70000;



//_____________DECLARATIONS__________________________________________________________
//LCD characters array
unsigned char bitmap[160*20];


//ADC vairables
//volatile unsigned short myx=0;
volatile unsigned short myy=0;
int choice=0;

//MMC variables
extern char mmc_buffer[128];
char mmc_buffer_test_1[128];
char state_mmc  = 1;
char flag_mmc=0;

//RTC
volatile U32 rtc_tics;
volatile U16 rtc_milliseconds;
volatile U16 rtc_seconds;
unsigned char rtc_running=0;

//CAN
char state_can = 1;
char state_can_1, state_can_2;
//_____________FUNCTIONS___________________________________________________________
void TCN_Config()
{
	TWBR=0xff;		//set frequency to 15 kHZ
	TWCR=0x44;
	TWSR=TWSR & 0xFC;//TWPS=00
	TCN_raddr=0b10010001;
	TCN_waddr=0b10010000;
	//TWSR=TWSR | 0x01;
}

/*********************************************************************************
Write to accelerometer register
**********************************************************************************/
  void acc_write(void){

	TWCR = (1<<TWINT) | (1<<TWSTA) | (1<<TWEN); // send START
	while(!(TWCR & (1<<TWINT)));
	if ((TWSR & 0xF8)!=TW_START)
		er=er+1;

	TWDR = I2C_slave<<1 | WRITE;			  //SLA2_W;	//load SLA_W
	TWCR = (1<<TWINT)|(1<<TWEN); //start transmission of address
	while(!(TWCR & (1<<TWINT)));
	if ((TWSR & 0xF8)!=TW_MT_SLA_ACK)
		er=er+1;
	
	TWDR=reg[0];			//send register address
	TWCR=(1<<TWINT) | (1<<TWEN);
	while(!(TWCR & (1<<TWINT)));
	if ((TWSR & 0xF8)!=TW_MT_DATA_ACK)
		er=er+1;
	
	TWDR=reg[1];				//send  data to register
	TWCR=(1<<TWINT) | (1<<TWEN);
	while(!(TWCR & (1<<TWINT)));
	if ((TWSR & 0xF8)!=TW_MT_DATA_ACK)
		er=er+1;
	
	TWCR = (1<<TWINT) | (1<<TWEN) | (1<<TWSTO);

  }
void my_acc_read(const unsigned char regr){

		reg[0]=regr;		

		TWCR = (1<<TWINT) | (1<<TWSTA) | (1<<TWEN); // send START
		while(!(TWCR & (1<<TWINT)));
		if ((TWSR & 0xF8)!=TW_START)
			er=er+1;

		TWDR = I2C_slave<<1 | WRITE;			  //SLA2_W;	//load SLA_W
		TWCR = (1<<TWINT)|(1<<TWEN); //start transmission of address
		while(!(TWCR & (1<<TWINT)));
		if ((TWSR & 0xF8)!=TW_MT_SLA_ACK)
			er=er+1;
	
		TWDR=reg[0];			//send register address
		TWCR=(1<<TWINT) | (1<<TWEN);
		while(!(TWCR & (1<<TWINT)));
		if ((TWSR & 0xF8)!=TW_MT_DATA_ACK)
			er=er+1;
	
		TWCR = (1<<TWINT) | (1<<TWEN) | (1<<TWSTO);

		TWCR = (1<<TWINT) | (1<<TWSTA) | (1<<TWEN); // send START
		while(!(TWCR & (1<<TWINT)));
		if ((TWSR & 0xF8)!=TW_START)
			er=er+1;

		TWDR = I2C_slave<<1 | READ;			  //load SLA_R
		TWCR = (1<<TWINT)|(1<<TWEN); //start transmission of address
		while(!(TWCR & (1<<TWINT)));
		if ((TWSR & 0xF8)!=TW_MR_SLA_ACK)
			er=er+1;
	
	
		TWCR = (1<<TWINT) | (1<<TWEN) | (1<<TWEA) ;
		while( (!(TWCR & (1<<TWINT))) && (timeout >0) )
				timeout--;
		reg[1]=TWDR;					//receive register contents
		if ((TWSR & 0xF8)!=TW_MR_DATA_ACK)
			er=er+1;

}
/*****************************************************************************
read accelerometer register
*****************************************************************************/
void acc_read(void){

	unsigned long timeout=700000;	

	//fictive write
	TWCR = (1<<TWINT) | (1<<TWSTA) | (1<<TWEN); // send START
	while(!(TWCR & (1<<TWINT)));
	if ((TWSR & 0xF8)!=TW_START)
		er=er+1;

	TWDR = I2C_slave<<1 | WRITE;			  //load SLA_W
	TWCR = (1<<TWINT)|(1<<TWEN); //start transmission of address
	while(!(TWCR & (1<<TWINT)));
	if ((TWSR & 0xF8)!=TW_MT_SLA_ACK)
		er=er+1;

	TWDR=reg[0];			//send register address
	TWCR=(1<<TWINT) | (1<<TWEN);
	while(!(TWCR & (1<<TWINT)));
	if ((TWSR & 0xF8)!=TW_MT_DATA_ACK)
		er=er+1;

	TWCR = (1<<TWINT) | (1<<TWEN) | (1<<TWSTO);
	
	//read X,Y,Z register contents
	TWCR = (1<<TWINT) | (1<<TWSTA) | (1<<TWEN); // send START
	while(!(TWCR & (1<<TWINT)));
	if ((TWSR & 0xF8)!=TW_START)
		er=er+1;

	TWDR = I2C_slave<<1 | READ;			  //load SLA_R
	TWCR = (1<<TWINT)|(1<<TWEN); //start transmission of address
	while(!(TWCR & (1<<TWINT)));
	if ((TWSR & 0xF8)!=TW_MR_SLA_ACK)
		er=er+1;
	
	//timeout=700000;
	
	TWCR = (1<<TWINT) | (1<<TWEN) | (1<<TWEA) ;
	while( (!(TWCR & (1<<TWINT))) && (timeout >0) )
			timeout--;
	xl=TWDR;					//receive X axis high byte
	if ((TWSR & 0xF8)!=TW_MR_DATA_ACK)
		er=er+1;
	
	timeout=70000;
	
	TWCR = (1<<TWINT) | (1<<TWEN) | (1<<TWEA) ;
	while( (!(TWCR & (1<<TWINT)))&& (timeout >0) )
			timeout--;
	xh=TWDR;						//receive X axis low byte
	if ((TWSR & 0xF8)!=TW_MR_DATA_ACK)
		er=er+1;

	timeout=700000;	

	TWCR = (1<<TWINT) | (1<<TWEN) | (1<<TWEA) ;
	while( (!(TWCR & (1<<TWINT))) && (timeout >0) )
			timeout--;
	yl=TWDR;					//receive Y axis high byte
	if ((TWSR & 0xF8)!=TW_MR_DATA_ACK)
		er=er+1;
	
	timeout=70000;
	
	TWCR = (1<<TWINT) | (1<<TWEN) | (1<<TWEA);
	while( (!(TWCR & (1<<TWINT)))&& (timeout >0) )
			timeout--;
	yh=TWDR;						//receive Y axis low byte
	if ((TWSR & 0xF8)!=TW_MR_DATA_ACK)
		er=er+1;


	TWCR = (1<<TWINT) | (1<<TWEN) | (1<<TWEA) ;
	while( (!(TWCR & (1<<TWINT))) && (timeout >0) )
			timeout--;
	zl=TWDR;					//receive Z axis high byte
	if ((TWSR & 0xF8)!=TW_MR_DATA_ACK)
		er=er+1;
	
	timeout=70000;
	
	TWCR = (1<<TWINT) | (1<<TWEN) ;
	while( (!(TWCR & (1<<TWINT)))&& (timeout >0) )
			timeout--;
	zh=TWDR;						//receive X axis low byte
	if ((TWSR & 0xF8)!=TW_MR_DATA_NACK)
		er=er+1;


	
	TWCR = (1<<TWINT) | (1<<TWEN) | (1<<TWSTO);
	

}

void Convert2Int(void){
 
 unsigned char tmp=0;

newx=xl & 0x01;	//new data received
tmp=xl >>6;
accx= (signed short)(xh<<2) | tmp;

newy=yl & 0x01;	//new data received
tmp=yl >>6;
accy= (signed short)(yh<<2) | tmp;

newz=zl & 0x01;	//new data received
tmp=zl >>6;
accz= (signed short)(zh<<2) | tmp;


}

void Convert2LCD(void){

//			sprintf(buf,"X=0x");
	if((accx / 1000)>0)
				{
					sym=accx / 1000;
					digitx[0]=sym+'0';//LCDChrXY(24,0,sym);
				}
				else digitx[0]='0';
				
				if ((accx / 100)>0)	{ 
					sym=accx / 100;
					accx=accx-sym*100;
					if (sym>9)
						sym=sym-10;
				  	digitx[1]=sym +'0';//printdigit(30,0,sym);//sym
			
				}	else digitx[1]= '0';

				if ((accx / 10)>0){ 
					sym=accx / 10;
					accx=accx-sym*10;
					if (sym>9)
						sym=sym-10;
				  	digitx[2]=sym+'0';//printdigit(36,0,sym);//sym
					digitx[3]=accx+'0';//printdigit(42,0,resx); //resx
				}	else {
					sym=accx % 10;
					digitx[2]='0';//printdigit(36,0,0);
					digitx[3]=sym+'0';//printdigit(42,0,sym);//sym
				}
	
			
				//sprintf(buf,"Y=0x");
				//LCDStr(1,buf,0);
				if((accy / 1000)>0){
					sym=accy / 1000;
					digity[0]=sym+'0';//LCDChrXY(24,1,sym);
				} else digity[0]='0';

				if ((accy / 100)>0)
				{ 
					sym=accy / 100;
					accy=accy-sym*100;
					if (sym>9)
						sym=sym-10;
				  	digity[1]=sym+'0';//printdigit(30,1,sym);//sym
			
				} else digity[1]= '0';
			
				if ((accy / 10)>0)
				{ 
					sym=accy / 10;
					accy=accy-sym*10;
					if (sym>9)
						sym=sym-10;
				  	digity[2]=sym+'0';//printdigit(36,1,sym);//sym
					digity[3]=accy+'0';//printdigit(42,1,resy); //resx
				}
				else {
					sym=accy % 10;
					digity[2]='0';//printdigit(36,1,0);
					digity[3]=sym+'0';//printdigit(42,1,sym);//sym
				}
			
				//sprintf(buf,"Z=0x");
				//LCDStr(2,buf,0);

				if((accz /1000)>0)
				{
					sym=accz / 1000;
					digitz[0]=sym+'0';//LCDChrXY(24,2,sym);
				} else digitz[0]='0';

				if ((accz / 100)>0)
				{ 
					sym=accz / 100;
					accz=accz-sym*100;
					if (sym>9)
						sym=sym-10;
				  	digitz[1]=sym+'0';//printdigit(30,2,sym);//sym
			
				} else digitz[1]= '0';

				if ((accz / 10)>0)
				{ 
					sym=accz / 10;
					accz=accz-sym*10;
					if (sym>9)
						sym=sym-10;
				  	digitz[2]=sym+'0';//printdigit(36,2,sym);//sym
					digitz[3]=accz+'0';//printdigit(42,2,resz); //resx
				 }
				else {
					sym=accz % 10;
					digitz[2]='0';//printdigit(36,2,0);
					digitz[3]=sym+'0';//printdigit(42,2,sym);//sym
				} 
	}

/*******************************************************************************
it's a simple delay
**********************************************************************************/
void Delay1 (unsigned long a) { while (--a!=0); }


/*
RTC interrupt initialization
*/
void rtc_int_init(unsigned long timeout)
{
unsigned short i;

     asm volatile("cli");//Disable_interrupt();


    Timer8_clear();                 //-- Timer 2 cleared & initialized "OFF"
    for (i=0;i<0xFFFF;i++);         //-- Waiting to let the Xtal stabilize after a power-on
    Timer8_overflow_it_disable();   //-- Disable OCIE2A interrupt
    Timer8_compare_a_it_disable();  //-- Disable TOIE2 interrupt
    //-- Config: - CTC mode (mode 2, top=OCR2A)
    //--         - No output
    //--        (- Timer "OFF")
    Timer8_set_mode_output_a(TIMER8_COMP_MODE_NORMAL);
    Timer8_set_waveform_mode(TIMER8_WGM_CTC_OCR);


    //--- Asynchronous external clock 32,768 KHZ
        Timer8_2_external_osc();            //-- Init RTC clock
        Timer8_set_compare_a(33-1);         //-- MAGIC_NUMBER !
        //-- No prescaler & timer "ON"
        //-- Tic interval: ((1/32768)*MAGIC_NUMBER) sec = 1.00708008 msec
        Timer8_set_clock(TIMER8_CLKIO_BY_1);

    while(Timer8_2_update_busy() && timeout--);    //-- Wait for TCN2UB, OCR2UB and TCR2UB to be cleared
	//check RTC for error
	if(!timeout)
		rtc_error=1;
    Timer8_clear_compare_a_it();      //-- Clear Output_Compare Interrupt-flags
    Timer8_compare_a_it_enable();     //-- Enable Timer2 Output_Compare Interrupt

    //-- Time setting
    rtc_tics         = 0;
    rtc_milliseconds = 0;

    rtc_running = 1;
    asm volatile("sei");//Enable_interrupt();
}


//------------------------------------------------------------------------------
//  @fn ISR(TIMER2_COMP_vect)
//! Timer2 Output_Compare INTerrupt routine. Increment tics & the real-time
//! clock, the interrupt occurs once a milli second (or close).
//! @param  none
//!
//! @return  none
//!
//------------------------------------------------------------------------------


ISR(TIMER2_COMP_vect)
{
    //rtc_tics++;                     //-- Increments tics
    rtc_milliseconds++;             //-- Increments milli seconds
//check this	flag_acc=0; 				//disable Accelerator values read

    if (rtc_milliseconds == 1000)
    {
        rtc_milliseconds = 0;
        rtc_seconds++;              //-- Increments seconds
		if(!dis_acc)
			flag_acc=1; 				//enable Accelerator values read
    }
}

/**********************************************************************
CAN - pin configuration and output test
***********************************************************************/
int can_test(void)
{
DDRD=DDRD & ~(1<<6); //RD1(bit 6) input
DDRD=DDRD | 1<<5;    //TD1(bit 5) output
PORTD = PORTD;

PORTC= PORTC & ~(1<<PC7);    //enable CAN
DDRC=DDRC |  1<<7;   //CAN_D(PC7)output

//SPP +
 bit_state = 0x00;
 PORTD=PORTD | 1<<5;		//send 1 to transmitter (bit 5)
 for (can_timeout = 250; can_timeout; can_timeout--)
 	if (PIND & 1<<6)
	{
		bit_state = 0x40;
		break;
	}
if (bit_state)		//read 1 on receiver (bit 6)
	state_can=1;			//test OK
else						//else
	{state_can=0;
	return 0;}				//test error

bit_state = 0x40;
PORTD=PORTD & ~(1<<5);		//send 0 to transmitter (bit 5)
for (can_timeout = 250; can_timeout; can_timeout--)
 	if ((~PIND) & 1<<6)
	{
		bit_state = 0x00;
		break;
	}
if (bit_state)		//read 1 on receiver (bit 6)
	{state_can=0;
	return 0;}				//test error
else						//else
	state_can=1;			//test OK
//SPP -

//DDRC=DDRC & ~(1<<7); //CAN_D(PC7)output
PORTC= PORTC | 1<<7;	//disable CAN (bit 7)

//SPP +
PORTD=PORTD | 1<<5;		//send 1 to transmitter (bit 5)
state_can_1 = PIND & 1<<6;//read x on receiver (bit 6)

PORTD=PORTD & ~(1<<5);	//send 0 to transmitter (bit 5)
state_can_2 = PIND & 1<<6;//read x on receiver (bit 6)

//CAN disabled ==>
//different input on transmitter same output to receiver
//state_can_1 and state_can_2 must have same value
if (state_can_1 = state_can_2)	//same value
	state_can = 1;				//test OK
else							//else
	{state_can = 0;return 0;}	//test error
//SPP -

//PORTD=PORTD;
}

/***********************************************************************
mmc test
************************************************************************/
void mmc_test(void){
	if((initMMC() == MMC_SUCCESS))	// card found
						{
						memset(&mmc_buffer,0x00,128);

						mmcReadRegister (10, 16);
			    		mmc_buffer[7]=0;

			    		// Fill first Block (0) with 'A'
			   			memset(&mmc_buffer,'0',128);    //set breakpoint and trace mmc_buffer contents
						mmcWriteBlock(0);
			    		// Fill second Block (1)-AbsAddr 512 with 'B'
			    		memset(&mmc_buffer,'1',128);
						mmcWriteBlock(512);

			   			 // Read first Block back to buffer
			   			memset(&mmc_buffer,0x00,128);
			    		mmcReadBlock(0,512);
						memset(&mmc_buffer_test_1,'0',128);
			    		if(strncmp(&mmc_buffer[0], &mmc_buffer_test_1[0], 128))
					 		state_mmc=1;
							else state_mmc  = 0;

			    		memset(&mmc_buffer,0x00,128); //set breakpoint and trace mmc_buffer contents
			    		mmcReadBlock(512,512);
						memset(&mmc_buffer_test_1,'1',128);
			    		if(strncmp(&mmc_buffer[0], &mmc_buffer_test_1[0], 128))
							state_mmc=1;
							else state_mmc  = 0;
						memset(&mmc_buffer,0x00,128); //set breakpoint and trace mmc_buffer contents

						//if ( !state_mmc)	printstr_p(PSTR("\n\r\tMMC card success"));
						//	else printstr_p(PSTR("\n\r\tMMC card error"));
						//printstr_p(PSTR("\n\r\tRemove MMC card"));
						flag_mmc=1;
						}

}
/**********************************************************************
timer1 config
***********************************************************************/
void timer1c_config(void){

	CLKPR =0x80;	//set CLKPCE bit
	CLKPR &=0xF0; //set division factor to 1
	Timer16_clear();				 //clear timer1 settings
	// Clock source: System Clock
	// Clock value: 8 000,000 kHz; t=125 nS
	// Mode: Normal top=FFFFh
#if 0
	Timer16_set_clock(TIMER16_CLKIO_BY_1);	//TIMER16_CLKIO_BY_1=1; clock source /1
	Timer16_set_waveform_mode(TIMER16_WGM_NORMAL) ;// TIMER16_WGM_NORMAL=0; set timer1 mode - Normal
	Timer16_set_mode_output_c(TIMER16_COMP_MODE_TOGGLE); //TIMER16_COMP_MODE_TOGGLE=1; Toggle OC1C on Compare Match.
	Timer16_set_compare_c(1); 	//3 set clock value for period - to be CALCULATED
	//Timer16_set_compare_a(5); //set clock value for period - to be CALCULATED
	DISP_ON;
	//Timer16_compare_c_it_enable(); 	//timer1c interrupt enable
	TIMSK1 |=  (1<<OCIE1C);
	asm volatile("sei");
#endif
}

/*************************************************************************************
LCD write routine use arguments:
	nmb - number of rows to display
	x - vertical position on first row
	y - horisontal position on first row
	char -starting char(optional)
	length - string length displayed on single row
****************************************************************************************/
void lcd_update(int nmb,int x, int y, char ch,int length)
{
//int cnt=0;//font bytes to be displayed
int pos=0;//char position to be written
//int cx=x;//row
//int cy=y;//column
//char mych=ch;//starting char
//int row_disp=0;//number of displayed rows
//int row=x+80;//(row-x)/8=rows to be displayed
unsigned char pl;
unsigned char ph;

	//load string for each row on display
	//del1
	

	//display on LCD
	pos=0;
	for(int i=0; i<(3200); i+=20) {
	    // below is loop for every col
		//row_disp=0;	//new row of pixels to display
		//cy=y;//update column number
		//if (cnt==8)	//cnt needs to be updated regularly 
		//	cnt=0;
		for(int j=0; j<20; j++) {
				// get data
      		 pl = bitmap[i+j];
      		 ph = pl>>4;
     		 pl &= 0xF;
			CP_HIGH;
	    	PORTA=(PORTA & 0xF0) | ph;	//send higher 4 bits on D3-D0
		  	// clock CP
		   	CP_LOW;

		  	CP_HIGH;
		  	PORTA=(PORTA& 0xF0) | pl ;	//send lower 4 bits on D3-D0
	      	// clock CP
		  	CP_LOW;
			//del2
		 }
		    if(i)
		    {
		      LP_HIGH;
		      LP_LOW;
		    }
		    else
		    { 
		      // start new frame
		      // for every new frame
		      FLM_HIGH;
		      LP_HIGH;
		      LP_LOW;
		      FLM_LOW;
		    }
  	}
}

/***************************************************************************************
****************************************************************************************/
void write_string(int row,int string_count,unsigned char * string,int inv){
		
		int pos=0;
		for(int count=0;count<20;count++){
			if(count<string_count)
				LCDWriteChar(0,0,row,pos,string[count],inv);
				else	LCDWriteChar(0,0,row,pos,' ',inv);
			pos=pos+1;
			}
}
/****************************************************************************************
Seconds indcator
****************************************************************************************/
void sec_ind(int seconds)
{
	char *buf=0;
	int ind=seconds %4;
	switch(ind)
	{
		case 0: *buf= '-' ;
				//LCDWriteChar(0,0,96,0,buf,0);
			break;

	 	case 1: *buf= '/' ;
				//LCDWriteChar(0,0,96,0,buf,0);
			break;
		
		case 2: *buf = '|' ;
				//LCDWriteChar(0,0,96,0,buf,0);
			break;
	
		case 3: *buf= '\\' ;
				//LCDWriteChar(0,0,96,0,buf,0);
			break;
	}

	write_string(96,1,buf,0);
}
/**************************************************************************************
ADC configuration
***************************************************************************************/
void init_adc(void){

  #if 0
	//measure X axis movement
  PORTF = PORTF | 1<<PF0;   // ADC1 to high
  PORTF = PORTF & ~(1<<PF1);// ADC2 to low
  PORTF = PORTF |1<<PF2;// ADC3 to  high(enable pullup)
  PORTF = PORTF |1<<PF3;// ADC4 to high(enable pullup)

  DDRF=DDRF | 1 <<DDF0; 	//ADC1 output
  DDRF=DDRF | 1 <<DDF1; 	//ADC2 output
  DDRF=DDRF & ~(1<<DDF2); 	//ADC3 input
  DDRF=DDRF & ~(1<<DDF3); 	//ADC4 input
  #endif

  #if 1
  //measure Y axis movement
  PORTF = PORTF | 1<<PF0;   // ADC0 to high (enable pullup)
  PORTF = PORTF | 1<<PF1;	// ADC1 to high(enable pullup)
  PORTF = PORTF | 1<<PF2;	// ADC2 to  high
  PORTF = PORTF & ~(1<<PF3);// ADC3 to low

  DDRF=DDRF & ~(1<<DDF0); 	//ADC0 input
  DDRF=DDRF & ~(1<<DDF1); 	//ADC1 input
  DDRF=DDRF | 1<<DDF2; 		//ADC2 output
  DDRF=DDRF | 1<<DDF3; 		//ADC3 output
  #endif



  ADMUX  &= ~((1<<REFS1)|(1<<REFS0)); //external VREF
  // ADMUX  &= ~(1<<REFS1);	//Enable_avcc_as_vref
  // ADMUX  |=  (1<<REFS0) ;

   ADMUX  &= ~(1<<ADLAR);	//clear left adjust

   ADMUX  &= ~(0x1F<<MUX0); //clear channel selection
   ADMUX |= (0<<MUX0);	//channel ADC0 select

	ADCSRA &= ~(0x07<<ADPS0);		 //clear prescaler
 	ADCSRA |= (ADC_PRESCALER<<ADPS0); //select prescaler
}

void test_ext_switch(unsigned char error){

	switch(error){

		case 0x0:	write_string(64,11,success_ext,0);

			break;

		case 0x01:	
			#if 0
			write_string(64,7,gnd,0);
			#else
			ZP[0] = 'G'; ZP[1] = 'N'; ZP[2] = 'D'; ZP[7] = P2; ZP[8] = B2;	//SPP
			write_string(64, 9, ZP, 0);
			ZP[2] = ' ';
			#endif
			break;

		case 0x02:
			#if 0
			write_string(64,7,vcc,0);
			#else
			ZP[0] = 'V'; ZP[1] = 'C'; ZP[2] = 'C'; ZP[7] = P2; ZP[8] = B2;	//SPP
			write_string(64, 9, ZP, 0);
			ZP[2] = ' ';
			#endif
			break;
		default:
			ZP[0] = P1; ZP[1] = B1; ZP[7] = P2; ZP[8] = B2;	//SPP
			write_string(64, 9, ZP, 0);
			break;

		
		/*
		case 0x03:	write_string(64,9,zb,0);
			break;

		case 0x04:	write_string(64,9,zc,0);
			break;

		case 0x05:	write_string(64,9,zd,0);
			break;

		case 0x06:	write_string(64,9,zg,0);
			break;

		case 0x07:	write_string(64,9,ze,0);
			break;*/

	}
	
}

void InitAll()
{
  		PullUpHigh();
		//initialize LCD
		InitLCD();

		//LCD on
		 LCD_Off();
		 LCD_On();
		
		//RTC INIT
		timer1c_config();	//Timer 1 configuration
		init_adc();			//ADC configuration
		rtc_int_init(50000);		//RealTimeClock configuration
	
	//	test_extension();
		//	TEST CAN
		//can_test();
		//Timer16_compare_c_it_enable(); 	//timer1c interrupt enable

		//1)Init AVR I2C interface 
		TCN_Config();//use my function insteadI2C_InitMaster(375000);	
		//2)INIT Accelerometer
		// are any commands to configure are required or just wake-up??????????????
		//*)try read chip id

}

//_______________________MAIN PROGRAM______________________________________
int main(void){
		InitAll();
		Delay1(1000);
		
		
		DDRC = DDRC | (1<<DDC6);  // disable back light	
		PORTC &=~(1<<PORTC6);
		ADCSRA |=  (1<<ADEN); 	//enable ADC

		while (timer_)
		{
			sum_adc = 0;
			while(meas_cnt<precision)
			{
		  	  ADCSRA &= ~(1<<ADATE); 	//start conversion
		  	  ADCSRA |=  (1<<ADSC) ;
		  	  while(!(ADCSRA  &  (1<<ADIF))); // wait until conversion complete
		  	  myy=ADC;
		  	  sum_adc +=myy;//suming measurements
			  adc_arr[meas_cnt]=myy;//dump ADC values
		  	  meas_cnt++;//increment ADC value count
		      ADCSRA |=  (1<<ADIF); //clear ADIF flag
			  Delay1(500);
			}
		  	meas_cnt=0;
		  	myy=sum_adc/precision;
			sum_adc = 0;
			timer_--;
			if (myy>320) break;
		}

		/*#if !timer_
		#define WORK	1
		#else
		#define WORK	0
		#endif*/
		WORK = !timer_;



		// clear screen
		 //LCDWriteBlank();
		/*write_string(0,16,board_name,0);
		write_string(8,10,menu,0);
		write_string(16,14,test_ext1,0);
		write_string(24,8,test_can,0);
		write_string(32,8,test_mmc,0);
		write_string(40,16,test_acc,0);
		write_string(48,13,backlight,0);
		write_string(56,6,state,1);*/

		write_string(0,16,board_name,0);
		write_string(8,10,menu,0);
		write_string(24,8,test_can,0);
		write_string(32,8,test_mmc,0);
		write_string(40,16,test_acc,0);
		write_string(48,13,backlight,0);
		write_string(56,6,state,1);
		if (WORK)
		write_string(144,14,test_ext1,0);

		while(1){
			sum_adc = 0;
			DDRC = DDRC | (1<<DDC6);  
		 // init_adc();			//ADC configuration
		  while(meas_cnt<precision){
		  	  
		  	  ADCSRA &= ~(1<<ADATE); 	//start conversion
		  	  ADCSRA |=  (1<<ADSC) ;
		  	  while(!(ADCSRA  &  (1<<ADIF))); // wait until conversion complete
		  	  myy=ADC;
		  	  sum_adc +=myy;//suming measurements
			  adc_arr[meas_cnt]=myy;//dump ADC values
		  	  meas_cnt++;//increment ADC value count
		      ADCSRA |=  (1<<ADIF); //clear ADIF flag
			  Delay1(500);
			}
		  
		  meas_cnt=0;
		  myy=sum_adc/precision;
		  if (card_state & (((~PING) & 1<<1)>>1))
		  {
		  	myy = 770;	//card test option
			card_state = 0;
			Delay1(100);
		  }
		//	if(PINE & 0x40){
		//		write_string(64,3,one,0);
			if(flag_acc){
				flag_acc=0;
				reg[0]=0x02;//data register address
				acc_read();
				Convert2Int();
				Convert2LCD();
				write_string(72,4,digitx,0);
				write_string(80,4,digity,0);
				write_string(88,4,digitz,0);			
				}
		//	}
		//	else	write_string(64,4,zero,0);
		  //lcd_update(10,0,0,'a',12);
		//	LCDWriteBlank();
			if(bl_en && !bl_rel && !bl_on){
					//DDRC = DDRC | 1<<DDC6;  // enable back light
					PORTC |=1<<PORTC6;//on
					bl_en=0;
					bl_on=1;
					}
				else if(bl_en && !bl_rel && bl_on)
					{
					PORTC &=~(1<<PORTC6);//off
					bl_en=0;
					bl_on=0;
					}	

		//ITEM selection
		#if 1
	//	if(meas_cnt==5){
	//			myy=sum_adc/8;
				if(myy > 860){//850		//860
					choice=1;
					//dis_acc=1;
					meas_cnt=0;
					sum_adc=0;
					bl_rel=0;
					}
					else if (myy>845){//800		//830
						choice=2;
						//dis_acc=1;
						meas_cnt=0;
						sum_adc=0;
						bl_rel=0;
						}
					else if ((myy<805) & (myy>785)){//670		//770
						InitAll();
						choice=4;
						dis_acc=1;
						meas_cnt=0;
						sum_adc=0;
						can_test();
						card_state = 0;
						if(state_can)
							write_string(64,11,success_can,0);
						else
							write_string(64,9,error_can,0);
						bl_rel=0;
						}
					else if ((myy<780) & (myy>760)){//650		740
						InitAll();
						choice=5;
						dis_acc=1;
						meas_cnt=0;
						sum_adc=0;
					//	if(!flag_mmc){
							if (!(PING & 0x02))
							{
								if (!(PING & 0x01))
									{
										mmc_test();
										if(!state_mmc)
											write_string(64,11,success_mmc,0);
										else
											write_string(64,9,error_mmc,0);
									}
								else
								{								
									write_string(64,19,protect,0);
								}
							}
							else 
							{
								if (WORK)
									write_string(64,19,put,0);
								else
									write_string(64, 8,put,0);
								card_state = 1;
							}
						bl_rel=0;
			//	}
						}
					else if ((myy<755) & (myy>735)){//600		//730
						InitAll();
						choice=6;
						dis_acc=0;
						flag_acc=1;
						card_state = 0;
						write_string(64,3,acc,0);
						meas_cnt=0;
						sum_adc=0;
						bl_rel=0;
						}
					else if ((myy<730) & (myy>710)){		//695
						InitAll();
						choice=7;
						dis_acc=1;
						//EN_ON;	
						//DDRC = DDRC | 1<<DDC6;  // enable back light
						//PORTC |=1<<PORTC6;
						bl_en=1;
						card_state = 0;
						write_string(64,13,backlight,0);
						meas_cnt=0;
						sum_adc=0;
						bl_rel=1;
						}
					/*else if (myy>650){		//650
						choice=8;
						meas_cnt=0;
						sum_adc=0;
						}*/
					else if (WORK & ((myy<420) & (myy>385))){//845 - 825
						InitAll();
						choice=3;
						dis_acc=1;
						//SPP +
						SPCR = 0x00;
						bit_state = TWCR & 0b00000100;
						TWCR = TWCR & 0b11111011;	//Bit TWEN = 0 to test PD0&PD1
						test_extension();
						TWCR = TWCR | bit_state;	//Bit TWEN = 1
						
						//SPP -

						card_state = 0;
						test_ext_switch(test_ext);
						InitLCD();
						LCD_Off();
						LCD_On();
						bl_rel=0;
						}
			sum_adc = 0;
			if (!dis_acc) sec_ind(rtc_seconds);		//rtc seconds indicator
			lcd_update(10,0,0,'a',12);	//update screen
		//	}
			



			#endif
	}

}
