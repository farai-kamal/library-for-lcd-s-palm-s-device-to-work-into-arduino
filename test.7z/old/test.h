//SPP +
//PORTB: 0, 1, 2, 3, 4, 5, 6
#define mask_port_b 0x7E	
//PORTC: 0, 1, 2, 3, 4, 5
#define mask_port_c 0x3F
//PORTD: 0, 1, 2, 3, 4, 7
#define mask_port_d 0x9F
//PORTE: 2, 3, 4, 5, 7
#define mask_port_e 0xBC
//PORTG: 0, 1, 2
#define mask_port_g 0x07
//SPP -

#define success 	0x00
#define error_gnd	0x01
#define error_vcc	0x02
#define error0_b	0x03
#define error0_c	0x04
#define error0_d	0x05
#define error0_e	0x06
#define error0_g	0x07



void AllAsInput(void) ;
//PULLUP - PB0
void pullup_low(void);
void pullup_high(void);

void PinAsOutputLowPortB(char pin);
void PinAsOutputHighPortB(char pin);

void PinAsOutputLowPortC(char pin);
void PinAsOutputHighPortC(char pin);

void PinAsOutputHighPortD(char pin);
void PinAsOutputLowPortD(char pin);

void PinAsOutputLowPortE(char pin);
void PinAsOutputHighPortE(char pin);

void PinAsOutputLowPortG(char pin);
void PinAsOutputHighPortG(char pin);


int test_extension(void);
