#include <avr/io.h>

#include "test.h"

unsigned char test_ext=0, P1, B1, P2, B2, X;
void Delay (unsigned long a) { while (--a!=0); }

void AllAsInput(void) 
{
	MCUCR |=0x10;
	//Port B initialization
	PORTB=0x00;
	DDRB=0x00;

	// Port C initialization
	PORTC=0x00;
	DDRC=0x00;
	
	// Port D initialization
	PORTD=0x00;
	DDRD=0x00;

	// Port E initialization
	PORTE=0x00;
	DDRE=0x00;

	// Port G initialization
	PORTG=0x00;
	DDRG=0x00;

	MCUCR |=0x10; //disable pullups
}

void PullUpHigh(void)
{
	PORTB =0x01;
	DDRB  =0x01;
	PORTB =0x01;

}

void PullUpLow(void)
{
	
	PORTB &=~(0x01);
	DDRB =0x01;
	PORTB &=~(0x01);
}


void PinAsOutputLowPortB(char pin) {

  switch (pin) {
    case  0: PORTB=PORTB & 0b11111110;	DDRB=0x01; DDRB|=0b00000001; break;
    case  1: PORTB=PORTB & 0b11111101;	DDRB=0x02; DDRB|=0b00000001; break;
    case  2: PORTB=PORTB & 0b11111011;	DDRB=0x04; DDRB|=0b00000001; break;
    case  3: PORTB=PORTB & 0b11110111;	DDRB=0x08; DDRB|=0b00000001; break;
    case  4: PORTB=PORTB & 0b11101111;	DDRB=0x10; DDRB|=0b00000001; break;
    case  5: PORTB=PORTB & 0b11011111;	DDRB=0x20; DDRB|=0b00000001; break;
    case  6: PORTB=PORTB & 0b10111111;	DDRB=0x40; DDRB|=0b00000001; break;
    case  7: PORTB=PORTB & 0b01111111;	DDRB=0x80; DDRB|=0b00000001; break;
    
  }

}


void PinAsOutputLowPortC(char pin) {

  switch (pin) {
    case  0: PORTC=PORTC & 0b11111110;	DDRC=0x01; 	break;
    case  1: PORTC=PORTC & 0b11111101;	DDRC=0x02;	break;
    case  2: PORTC=PORTC & 0b11111011;	DDRC=0x04;	break;
    case  3: PORTC=PORTC & 0b11110111;	DDRC=0x08;	break;
    case  4: PORTC=PORTC & 0b11101111;	DDRC=0x10;	break;
    case  5: PORTC=PORTC & 0b11011111;	DDRC=0x20;	break;
    case  6: PORTC=PORTC & 0b10111111;	DDRC=0x40;	break;
    case  7: PORTC=PORTC & 0b01111111;	DDRC=0x80;  break;
      }

}

void PinAsOutputLowPortD(char pin) {
/*	if(((mask_port_d)&(1<<i)))
		PORTD=0xff;*/
  switch (pin) {
    case  0: PORTD=PORTD  & 0b11111110;	DDRD=0x01;  break;
    case  1: PORTD=PORTD  & 0b11111101;	DDRD=0x02;	break;
	case  2: PORTD=PORTD  & 0b11111011;	DDRD=0x04;	break;
    case  3: PORTD=PORTD  & 0b11110111;	DDRD=0x08;	break;
    case  4: PORTD=PORTD  & 0b11101111;	DDRD=0x10;	break;
    case  5: PORTD=PORTD  & 0b11011111;	DDRD=0x20;	break;
    case  6: PORTD=PORTD  & 0b10111111;	DDRD=0x40;	break;
    case  7: PORTD=PORTD  & 0b01111111; DDRD=0x80;	break;
      }

}

void PinAsOutputLowPortE(char pin) {

  switch (pin) {
    case  0: PORTE=PORTE & 0b11111110;	DDRE=0x01; 	break;
    case  1: PORTE=PORTE & 0b11111101;	DDRE=0x02;	break;
    case  2: PORTE=PORTE & 0b11111011;	DDRE=0x04;	break;
    case  3: PORTE=PORTE & 0b11110111;	DDRE=0x08;	break;
    case  4: PORTE=PORTE & 0b11101111;	DDRE=0x10;	break;
    case  5: PORTE=PORTE & 0b11011111;	DDRE=0x20;	break;
    case  6: PORTE=PORTE & 0b10111111;	DDRE=0x40;	break;
    case  7: PORTE=PORTE & 0b01111111;	DDRE=0x80;  break;
      }

}

void PinAsOutputLowPortG(char pin) {

  switch (pin) {
    case  0: PORTG=PORTG & 0b11111110;	DDRG=0x01; 	break;
    case  1: PORTG=PORTG & 0b11111101;	DDRG=0x02;	break;
    case  2: PORTG=PORTG & 0b11111011;	DDRG=0x04;	break;
    case  3: PORTG=PORTG & 0b11110111;	DDRG=0x08;	break;
    case  4: PORTG=PORTG & 0b11101111;	DDRG=0x10;	break;
    case  5: PORTG=PORTG & 0b11011111;	DDRG=0x20;	break;
    case  6: PORTG=PORTG & 0b10111111;	DDRG=0x40;	break;
    case  7: PORTG=PORTG & 0b01111111;	DDRG=0x80;  break;
      }

}

void PinAsOutputHighPortB(char pin) {

  switch (pin) {
    case  0: PORTB= 0b00000001;	DDRB=0x01; DDRB|=0b00000001; break;
    case  1: PORTB= 0b00000010;	DDRB=0x02; DDRB|=0b00000001; break;
    case  2: PORTB= 0b00000100;	DDRB=0x04; DDRB|=0b00000001; break;
    case  3: PORTB= 0b00001000;	DDRB=0x08; DDRB|=0b00000001; break;//PORTB | 
    case  4: PORTB= 0b00010000;	DDRB=0x10; DDRB|=0b00000001; break;//PORTB | 
    case  5: PORTB= 0b00100000;	DDRB=0x20; DDRB|=0b00000001; break;//PORTB |
    case  6: PORTB= 0b01000000;	DDRB=0x40; DDRB|=0b00000001; break;//PORTB |
    case  7: PORTB= 0b10000000;	DDRB=0x80; DDRB|=0b00000001; break;//PORTB |
    
  }

}


void PinAsOutputHighPortC(char pin) {

  switch (pin) {
    case  0: PORTC= 0b00000001;	DDRC=0x01; 	break;	//PORTC |
    case  1: PORTC= 0b00000010;	DDRC=0x02;	break;	//PORTC |
    case  2: PORTC= 0b00000100;	DDRC=0x04;	break;//PORTC |
    case  3: PORTC= 0b00001000;	DDRC=0x08;	break;//PORTC |
    case  4: PORTC= 0b00010000;	DDRC=0x10;	break;//PORTC |
    case  5: PORTC= 0b00100000;	DDRC=0x20;	break;//PORTC |
    case  6: PORTC=0b01000000;	DDRC=0x40;	break;//PORTC | 
    case  7: PORTC=0b10000000;	DDRC=0x80;  break;//PORTC | 
      }

}

void PinAsOutputHighPortD(char pin) {

  switch (pin) {
    case  0: PORTD = 0b00000001;	DDRD=0x01; break;
    case  1: PORTD = 0b00000010;	DDRD=0x02; break;
	case  2: PORTD = 0b00000100;	DDRD=0x04; break;
    case  3: PORTD = 0b00001000;	DDRD=0x08; break;
    case  4: PORTD = 0b00010000;	DDRB=0x10; break;
    case  5: PORTD = 0b00100000;	DDRD=0x20; break;
    case  6: PORTD = 0b01000000;	DDRD=0x40; break;
	case  7: PORTD = 0b01111111; 	DDRD=0x80; break;
      }

}

void PinAsOutputHighPortE(char pin) {

  switch (pin) {
    case  0: PORTE= 0b00000001;	DDRE=0x01; 	break;	
	case  1: PORTE= 0b00000010;	DDRE=0x02;	break;
    case  2: PORTE= 0b00000100;	DDRE=0x04;	break;
    case  3: PORTE= 0b00001000;	DDRE=0x08;	break;
    case  4: PORTE= 0b00010000;	DDRE=0x10;	break;//PORTC |
    case  5: PORTE= 0b00100000;	DDRE=0x20;	break;//PORTC |
    case  6: PORTE= 0b01000000;	DDRE=0x40;	break;//PORTC | 
    case  7: PORTE= 0b10000000;	DDRE=0x80; break;//PORTC | 
      }

}

void PinAsOutputHighPortG(char pin) {

  switch (pin) {
    case  0: PORTG= 0b00000001;	DDRG=0x01; 	break;
    case  1: PORTG= 0b00000010;	DDRG=0x02;	break;
    case  2: PORTG= 0b00000100;	DDRG=0x04;	break;
    case  3: PORTG= 0b00001000;	DDRG=0x08;	break;
    case  4: PORTG= 0b00010000;	DDRG=0x10;	break;
    case  5: PORTG= 0b00100000;	DDRG=0x20;	break;
    case  6: PORTG= 0b01000000;	DDRG=0x40;	break; 
    case  7: PORTG= 0b10000000;	DDRG=0x80; break;
      }

}


int test_extension(void) {

	int i=0;  

  // Test for GND ==============================================================
 unsigned char tempstate;
 AllAsInput();
  PullUpHigh();

  Delay(1000);

  //tempstate = PINC |(~mask_port_c);

  if((unsigned char)((PINB)|(~mask_port_b)) != 0xFF) 
  		{
		//SPP +
		P2 = 'B';	B2 = 48;
		X = ((~PINB) & mask_port_b);
		while (X>1) {X/=2; B2++;}
		//SPP -

		test_ext=0x01;
		return 0;
		 }
  if((unsigned char)((PINC)|(~mask_port_c)) != 0xFF)
  		{
		//SPP +
		P2 = 'C';	B2 = 48;
		X = ((~PINC) & mask_port_c);
		while (X>1) {X/=2; B2++;}
		//SPP -

		test_ext=0x01;
		return 0;
		 }
  if((unsigned char)((PIND) |(~mask_port_d)) != 0xFF) 
  		{
		//SPP +
		P2 = 'D';	B2 = 48;
		X = ((~PIND) & mask_port_d);
		while (X>1) {X/=2; B2++;}
		//SPP -

		test_ext=0x01;
		return 0;
		 }
 if((unsigned char)((PINE) |(~mask_port_e)) != 0xFF) 
  		{
		//SPP +
		P2 = 'E';	B2 = 48;
		X = ((~PINE) & mask_port_e);
		while (X>1) {X/=2; B2++;}
		//SPP -

		test_ext=0x01;
		return 0;
		 }
 if((unsigned char)((PING) |(~mask_port_g)) != 0xFF) 
  		{
		//SPP +
		P2 = 'G';	B2 = 48;
		X = ((~PING) & mask_port_g);
		while (X>1) {X/=2; B2++;}
		//SPP -

		test_ext=0x01;
		return 0;
		 }
 

  // End =======================================================================


  // Test for VCC ==============================================================
  AllAsInput();
  PullUpLow();

  Delay(1000);

  if((unsigned char)(PINB & mask_port_b )!= 0x0) 
  		{
		//SPP +
		P2 = 'B';	B2 = 48;
		X = PINB & mask_port_b;
		while (X>1) {X/=2; B2++;}
		//SPP -

		test_ext=0x02;
		return 0;
		 }
  if((unsigned char)(PINC & mask_port_c)!= 0x0) 
  		{
		//SPP +
		P2 = 'C';	B2 = 48;
		X = PINC & mask_port_c;
		while (X>1) {X/=2; B2++;}
		//SPP -

		test_ext=0x02;
		return 0;
		 }
  if((unsigned char)(PIND & mask_port_d) != 0x0) 
  		{
		//SPP +
		P2 = 'D';	B2 = 48;
		X = PIND & mask_port_d;
		while (X>1) {X/=2; B2++;}
		//SPP -

		test_ext=0x02;
		return 0;
		 }
  if((unsigned char)(PINE & mask_port_e)!= 0x0) 
  		{
		//SPP +
		P2 = 'E';	B2 = 48;
		X = PINE & mask_port_e;
		while (X>1) {X/=2; B2++;}
		//SPP -

		test_ext=0x02;
		return 0;
		 }
  if((unsigned char)(PING & mask_port_g)!= 0x0) 
  		{
		//SPP +
		P2 = 'G';	B2 = 48;
		X = PING & mask_port_g;
		while (X>1) {X/=2; B2++;}
		//SPP -

		test_ext=0x02;
		return 0;
		 }  

  // End =======================================================================


  // Running zero ==============================================================
  AllAsInput();
  PullUpHigh();


    // PortB
  for(i=0; i<8; i++) {

    // this port is not tested
    if(!((mask_port_b)&(1<<i))) continue;

    PinAsOutputLowPortB(i);

    Delay(1000);

	tempstate = PINB |(~mask_port_b);

    if((unsigned char)((PINB)|(~mask_port_b)) != ((0xFF)&(~(1<<i)))) 
		{
		//SPP +
		P1 ='B'; B1 = i + 48; P2 = 'B';	B2 = 48;
		X = ((~PINB) & mask_port_b) - (1<<i);
		while (X>1) {X/=2; B2++;}
		//SPP -

		test_ext=error0_b;
		return 0;
		 }
    if((unsigned char)((PINC) |(~mask_port_c))!= 0xFF)
		{
		//SPP +
		P1 ='B'; B1 = i + 48; P2 = 'C';	B2 = 48;
		X = ((~PINC) & mask_port_c);
		while (X>1) {X/=2; B2++;}
		//SPP -

		test_ext=error0_c;
		return 0;
		 }
    if((unsigned char)((PIND) |(~mask_port_d)) != 0xFF)
		{
		//SPP +
		P1 ='B'; B1 = i + 48; P2 = 'D';	B2 = 48;
		X = ((~PIND) & mask_port_d);
		while (X>1) {X/=2; B2++;}
		//SPP -

		test_ext=error0_d;
		return 0;
		 }
	if((unsigned char)((PINE) |(~mask_port_e))!= 0xFF)
		{
		//SPP +
		P1 ='B'; B1 = i + 48; P2 = 'E';	B2 = 48;
		X = ((~PINE) & mask_port_e);
		while (X>1) {X/=2; B2++;}
		//SPP -

		test_ext=error0_e;
		return 0;
		 }
    if((unsigned char)((PING) |(~mask_port_g)) != 0xFF)
		{
		//SPP +
		P1 ='B'; B1 = i + 48; P2 = 'G';	B2 = 48;
		X = ((~PING) & mask_port_g);
		while (X>1) {X/=2; B2++;}
		//SPP -

		test_ext=error0_g;
		return 0;
		 }

  }

  AllAsInput();
  PullUpHigh();

  // PortC
  for(i=0; i<8; i++) {

    // this port is not tested
    if(!((mask_port_c)&(1<<i))) continue;

    PinAsOutputLowPortC(i);

    Delay(1000);

    if((unsigned char)((PINB)|(~mask_port_b)) != 0xFF)               
		{
		//SPP +
		P1 ='C'; B1 = i + 48; P2 = 'B';	B2 = 48;
		X = ((~PINB) & mask_port_b);
		while (X>1) {X/=2; B2++;}
		//SPP -

		test_ext=error0_b;
		return 0;
		 }
    if((unsigned char)((PINC) |(~mask_port_c))!= ((0xFF)&(~(1<<i)))) 
	{
		//SPP +
		P1 ='C'; B1 = i + 48; P2 = 'C';	B2 = 48;
		X = ((~PINC) & mask_port_c) - (1<<i);
		while (X>1) {X/=2; B2++;}
		//SPP -

		test_ext=error0_c;
		return 0;
		 }
    if((unsigned char)((PIND) |(~mask_port_d)) != 0xFF)
		{
		//SPP +
		P1 ='C'; B1 = i + 48; P2 = 'D';	B2 = 48;
		X = ((~PIND) & mask_port_d);
		while (X>1) {X/=2; B2++;}
		//SPP -

		test_ext=error0_d;
		return 0;
		 }
	if((unsigned char)((PINE) |(~mask_port_e))!= (0xFF)) 
	{
		//SPP +
		P1 ='C'; B1 = i + 48; P2 = 'E';	B2 = 48;
		X = ((~PINE) & mask_port_e);
		while (X>1) {X/=2; B2++;}
		//SPP -

		test_ext=error0_e;
		return 0;
		 }
    if((unsigned char)((PING) |(~mask_port_g)) != (0xFF))
		{
		//SPP +
		P1 ='C'; B1 = i + 48; P2 = 'G';	B2 = 48;
		X = ((~PING) & mask_port_g);
		while (X>1) {X/=2; B2++;}
		//SPP -

		test_ext=error0_g;
		return 0;
		 }

  }


  AllAsInput();
  PullUpHigh();

  // PortD
  for(i=0; i<8; i++) {

    // this port is not tested
    if(!((mask_port_d)&(1<<i))) continue;

    PinAsOutputLowPortD(i);
	tempstate = PIND | (~mask_port_d);
    Delay(1000);

    if((unsigned char)((PINB) | (~mask_port_b))!= 0xFF)               
		{ 
		//SPP +
		P1 ='D'; B1 = i + 48; P2 = 'B';	B2 = 48;
		X = ((~PINB) & mask_port_b);
		while (X>1) {X/=2; B2++;}
		//SPP -

		test_ext=error0_b;
		 return 0;
		 }
    if((unsigned char)((PINC) |(~mask_port_c)) != 0xFF)               
		{ 
		//SPP +
		P1 ='D'; B1 = i + 48; P2 = 'C';	B2 = 48;
		X = ((~PINC) & mask_port_c);
		while (X>1) {X/=2; B2++;}
		//SPP -

		test_ext=error0_c;
		 return 0;
		  }

    if((unsigned char)(PIND|(~mask_port_d))!= ((0xFF)&(~(1<<i)))) 
		{
		//SPP +
		P1 ='D'; B1 = i + 48; P2 = 'D';	B2 = 48;
		X = ((~PIND) & mask_port_d) - (1<<i);
		while (X>1) {X/=2; B2++;}
		//SPP -

		test_ext=error0_d;
		 return 0;
		 }
	if((unsigned char)((PINE)|(~mask_port_e)) != 0xFF)               
		{ 
		//SPP +
		P1 ='D'; B1 = i + 48; P2 = 'E';	B2 = 48;
		X = ((~PINE) & mask_port_e);
		while (X>1) {X/=2; B2++;}
		//SPP -

		test_ext=error0_e;
		 return 0;
		  }

    if((unsigned char)(PING|(~mask_port_g))!= (0xFF)) 
		{
		//SPP +
		P1 ='D'; B1 = i + 48; P2 = 'G';	B2 = 48;
		X = ((~PING) & mask_port_g);
		while (X>1) {X/=2; B2++;}
		//SPP -

		test_ext=error0_g;
		 return 0;
		 }

  }

  AllAsInput();
  PullUpHigh();

  // PortE
  for(i=0; i<8; i++) {

    // this port is not tested
    if(!((mask_port_e)&(1<<i))) continue;

    PinAsOutputLowPortE(i);
	tempstate = PINE | (~mask_port_e);
    Delay(1000);

    if((unsigned char)((PINB) | (~mask_port_b))!= 0xFF)               
		{ 
		//SPP +
		P1 ='E'; B1 = i + 48; P2 = 'B';	B2 = 48;
		X = ((~PINB) & mask_port_b);
		while (X>1) {X/=2; B2++;}
		//SPP -

		test_ext=error0_b;
		 return 0;
		 }
    if((unsigned char)((PINC) |(~mask_port_c)) != 0xFF)               
		{ 
		//SPP +
		P1 ='E'; B1 = i + 48; P2 = 'C';	B2 = 48;
		X = ((~PINC) & mask_port_c);
		while (X>1) {X/=2; B2++;}
		//SPP -
		test_ext=error0_c;
		 return 0;
		  }

    if((unsigned char)(PIND|(~mask_port_d))!= (0xFF)) 
		{
		//SPP +
		P1 ='E'; B1 = i + 48; P2 = 'D';	B2 = 48;
		X = ((~PIND) & mask_port_d);
		while (X>1) {X/=2; B2++;}
		//SPP -

		test_ext=error0_d;
		 return 0;
		 }
	if((unsigned char)((PINE)|(~mask_port_e)) != ((0xFF)&(~(1<<i))))               
		{ 
		//SPP +
		P1 ='E'; B1 = i + 48; P2 = 'E';	B2 = 48;
		X = ((~PINE) & mask_port_e) - (1<<i);
		while (X>1) {X/=2; B2++;}
		//SPP -

		test_ext=error0_e;
		 return 0;
		  }

    if((unsigned char)(PING|(~mask_port_g))!= (0xFF)) 
		{
		//SPP +
		P1 ='E'; B1 = i + 48; P2 = 'G';	B2 = 48;
		X = ((~PING) & mask_port_g);
		while (X>1) {X/=2; B2++;}
		//SPP -

		test_ext=error0_g;
		 return 0;
		 }

  }

  AllAsInput();
  PullUpHigh();

  // PortG
  for(i=0; i<8; i++) {

    // this port is not tested
    if(!((mask_port_g)&(1<<i))) continue;

    PinAsOutputLowPortG(i);
	tempstate = PING | (~mask_port_g);
    Delay(1000);

    if((unsigned char)((PINB) | (~mask_port_b))!= 0xFF)               
		{
		//SPP +
		P1 ='G'; B1 = i + 48; P2 = 'B';	B2 = 48;
		X = ((~PINB) & mask_port_b);
		while (X>1) {X/=2; B2++;}
		//SPP -

		test_ext= error0_b;
		 return 0;
		 }
    if((unsigned char)((PINC) |(~mask_port_c)) != 0xFF)               
		{ 
		//SPP +
		P1 ='G'; B1 = i + 48; P2 = 'C';	B2 = 48;
		X = ((~PINC) & mask_port_c);
		while (X>1) {X/=2; B2++;}
		//SPP -

		test_ext= error0_c;
		 return 0;
		  }

    if((unsigned char)(PIND|(~mask_port_d))!= (0xFF)) 
		{
		//SPP +
		P1 ='G'; B1 = i + 48; P2 = 'D';	B2 = 48;
		X = ((~PIND) & mask_port_d);
		while (X>1) {X/=2; B2++;}
		//SPP -

		test_ext= error0_d;
		 return 0;
		 }
	if((unsigned char)((PINE)|(~mask_port_e)) != 0xFF)               
		{ 
		//SPP +
		P1 ='G'; B1 = i + 48; P2 = 'E';	B2 = 48;
		X = ((~PINE) & mask_port_e);
		while (X>1) {X/=2; B2++;}
		//SPP -

		test_ext= error0_e;
		 return 0;
		  }

    if((unsigned char)(PING|(~mask_port_g))!= ((0xFF)&(~(1<<i)))) 
		{
		//SPP +
		P1 ='G'; B1 = i + 48; P2 = 'G';	B2 = 48;
		X = ((~PING) & mask_port_g) - (1<<i);
		while (X>1) {X/=2; B2++;}
		//SPP -

		test_ext= error0_g;
		 return 0;
		 }

  }

  // End =======================================================================
	test_ext=0;
	return 0;
}
