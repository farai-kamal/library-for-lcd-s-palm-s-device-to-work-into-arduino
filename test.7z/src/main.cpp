#include <Arduino.h>
#include <PC1681WE05.h>
#include <font_8x8.h> // Make sure to include the font header file if not included already

 char bitmap[20 * 20]; // Define the bitmap array

PC1681WE05 lcd;

unsigned long lastDisplayTime = 0;
unsigned long displayInterval = 2000; // Display interval in milliseconds

void setup() {
  // Initialize LCD
  lcd.initLCD();
  lcd.lcdOn();
  lcd.setBacklight(2); // Set backlight to maximum intensity
  
  // Clear the screen
  lcd.writeBlank();
}

void loop() {
  unsigned long currentTime = millis();

  // Display "Hello, World!" every 'displayInterval' milliseconds
  if (currentTime - lastDisplayTime >= displayInterval) {
    lcd.writeBlank(); // Clear the screen before writing new text
    lcd.LCDWriteString(0, 0, (unsigned char*)"Hello, World!", 0);
    lastDisplayTime = currentTime;
  }

  // Your other non-blocking tasks can go here
  
  // For example, you can blink an LED or read sensors
  // without blocking the LCD update.
}
